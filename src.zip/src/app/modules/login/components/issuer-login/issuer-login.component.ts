import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-issuer-login',
  templateUrl: './issuer-login.component.html',
  styleUrls: ['./issuer-login.component.scss'],
})
export class IssuerLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
