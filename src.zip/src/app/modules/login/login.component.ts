
import { SharedService } from './../../shared/Services/shared.service';
import { Component, OnInit, OnChanges } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import * as Mydatas from '../../app-config.json';
import { LoginService } from './login.service';
import { AuthService } from '../../Auth/auth.service';
import Swal from 'sweetalert2';
import { HttpService } from 'src/app/shared/Services/http.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent {


  public menuActive: any = 'login';

  brokerLogin = true;
  value:string="Change Password"
  issuerLogin = false;
  brokerName = null;
  brokerPassword = null;
  issuerName = null;
  issuerPassword = null;branchList:any[]=[];
  invalidBroker = false;
  invalidIssuer = false;branchValue:any;
  issuerLogins = false;loginSection:boolean;
  brokerLogins = false;public submitted = false;public Proceed =false;
  public issuerBranch; public issuerRegion;
  public branches;
  public errorsList = new Array();public AppConfig: any = (Mydatas as any).default;
  public ApiUrl1: any = this.AppConfig.ApiUrl1;
  public CommonApiUrl: any = this.AppConfig.CommonApiUrl;
  public loginForm!: FormGroup;changeForm:FormGroup;
  regionList: any;userType:any;
  constructor(private _formBuilder: FormBuilder,private service: HttpService,
    private loginService:LoginService,private SharedService:SharedService,private authService: AuthService,
    private router: Router, ) {
    this.onLoginTap();

    sessionStorage.clear();
    this.service.ocQuoteMenu = false;
    this.service.navMenu = false;
    this.service.openCoverMenu = false;
    //this.getRegionList();
  }
change(value)
{
this.value=value;
if(value==="Change Password")
{
  this.loginSection=true;
}

}

  onLoginTap() {
    this.router.navigate([this.menuActive]);
  }
  ngOnInit(): void {
    this.onCreateFormControl();

  }
  onCreateFormControl() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      region: ['', Validators.required],
      branch: ['', Validators.required],
    });
    this.changeForm = this._formBuilder.group({
      LoginId: ['', Validators.required],
      NewPassword: ['', Validators.required],
      OldPassword: ['', Validators.required]
    });
  }

  reset()
  {
    sessionStorage.clear();
    this.authService.logout;
  }
submit()
{
  const urlLink = `${this.CommonApiUrl}basicauth/changepassword`;
    const formData = this.changeForm.value;

    const reqData = {
      "LoginId": formData.LoginId,
      "NewPassword": formData.NewPassword,
      "OldPassword": formData.OldPassword
    };
    this.SharedService.onPostMethodBasicSync(urlLink, reqData).subscribe(
      (data: any) => {
        let res:any = data;
        console.log(data);
          if(data.Result){
            Swal.fire({
              title: '<strong>Change Password </strong>',
              icon: 'info',
              html:
                `Password Updated Successfully`,
              //showCloseButton: true,
              //focusConfirm: false,
              showCancelButton:false,

             //confirmButtonColor: '#3085d6',
             cancelButtonColor: '#d33',
             //confirmButtonText: 'Proceed Login!',
             cancelButtonText: 'Cancel',
           })
            //sessionStorage.removeItem('customerReferenceNo');
            this.changeForm.reset();
            this.loginSection=false;
        }
      });

}
  get f() {
    return this.loginForm.controls;

  }


  onLogin() {
    this.submitted = true;
    const urlLink = `${this.CommonApiUrl}authentication/login`;
    const formData = this.loginForm.value;

    const reqData = {
      "LoginId": formData.username,
      "Password": formData.password,
      "ReLoginKey": "N"
    };

    this.loginService.onPostMethodSync(urlLink, reqData).subscribe(
      (data: any) => {
        let res:any = data;
        console.log(data);
        if (data.Result) {
          const Token = data?.Result?.Token;
          this.authService.login(data);
          this.authService.UserToken(Token);
          sessionStorage.setItem('Userdetails', JSON.stringify(data));
          sessionStorage.setItem('UserToken', Token);
          sessionStorage.setItem('menuSection', 'navMenu');
          this.userType = data.Result.UserType;
          if(data.Result.UserType=='Issuer' || data.Result.UserType=='Broker' || data.Result.UserType=='User'){
            let branchList:any[] = data?.Result?.LoginBranchDetails;
            if(branchList.length!=0 && branchList.length>1){
              console.log("Entered Branch",branchList)
            //this.loginSection = true;
            this.router.navigate(['/branch']);
            this.branchList = branchList;
            }
            else{
              this.branchList = branchList;
              if(this.userType == 'Issuer'){
                this.branchValue = branchList[0].BranchCode;
                this.onBranchProceed();
              }
              else{
                this.branchValue = branchList[0].BrokerBranchCode;
                this.onBranchProceed();
              }

            }
            //this.router.navigate(['/product']);
          }
          //this.router.navigate(['/Admin']);
        }
        else{
          // if(res.ErrorMessage){
          //   for(let entry of res.ErrorMessage){
          //     let type: NbComponentStatus = 'danger';
          //     const config = {
          //       status: type,
          //       destroyByClick: true,
          //       duration: 2000,
          //       hasIcon: true,
          //       position: NbGlobalPhysicalPosition.TOP_RIGHT,
          //       preventDuplicates: false,
          //     };
          //     this.toastrService.show(
          //       entry.Field,
          //       entry.Message,
          //       config);
          //   }
            // console.log("Error Iterate",data.ErrorMessage)
            // this.loginService.errorService(data.ErrorMessage);
          //}
        }
      },

      (err: any) => { console.log(err); },
    );
    //this.router.navigate(['/Admin']);
  }
  onCancel(){
    sessionStorage.clear();
    location.reload();
  }
  onBranchProceed(){
    this.Proceed = true;
    if(this.branchValue!='' && this.branchValue!=undefined){
      let userDetails = JSON.parse(sessionStorage.getItem('Userdetails'));
      if(this.userType =='Issuer'){
        let branchData:any = this.branchList.find(ele=>ele.BranchCode == this.branchValue);
        userDetails.Result['BrokerBranchCode'] = null;
        userDetails.Result['BranchCode'] = branchData.BranchCode;
        userDetails.Result['CurrencyId'] = branchData?.CurrencyId;
        userDetails.Result['InsuranceId'] = branchData?.InsuranceId;
        sessionStorage.setItem('Userdetails', JSON.stringify(userDetails));
        this.router.navigate(['/product']);
      }
      else{

        let branchData:any = this.branchList.find(ele=>ele.BrokerBranchCode == this.branchValue);
        console.log("Branch Value",this.branchValue,branchData)
        userDetails.Result['BrokerBranchCode'] = branchData.BrokerBranchCode;
        userDetails.Result['BranchCode'] = branchData.BranchCode;
        userDetails.Result['CurrencyId'] = branchData?.CurrencyId;
        userDetails.Result['InsuranceId'] = branchData?.InsuranceId;
        sessionStorage.setItem('Userdetails', JSON.stringify(userDetails));
        this.router.navigate(['/product']);
      }

    }
  }




  getRegionList() {
    this.service.IssuerLoginRegionList().subscribe(
      data => {
        sessionStorage.clear();
        this.regionList = data;
        console.log('Region', data);
      },
      error => { console.log('Error: ', error.message); });
  }
  getBranchList() {
    const branchReq = {
      'RegionCode': this.issuerRegion,
    };
    this.service.IssuerLoginBranchList(branchReq).subscribe(
      data => {
        this.branches = data;
        console.log('BranchList', data);
      },
      error => { console.log('Error: ', error.message); });
  }
  brokersLogin() {
    this.router.navigate(['/Admin/dashboard']);
  }
  issuersLogin() {
    this.errorsList = [];
    console.log('Uname', this.issuerName);
    console.log('Password', this.issuerPassword);
    const uname = this.issuerName;
    const password = this.issuerPassword;
      this.invalidIssuer = false;
      const loginData = {
        UserId: uname,
        Password : password,
        LoginType : 'Admin',
        RegionCode : this.issuerRegion,
        BranchCode : this.issuerBranch,
      };
      this.service.getBrokerLogin(loginData).subscribe(
        data => {
          console.log('LoginResponse', data);
          if (data.Errors) {
            for (const err of data.Errors) {
              let count = 0;
              if (Array.isArray(this.errorsList)) {
                for (const list of this.errorsList) {
                  if (list.message == err.message) {
                    count += 1;
                  } else {
                    count = 0;
                  }
                }
              }
              if (count == 0 && err.message) {
                  this.errorsList.push(err.message);
              }
            }
            for (const err of data.Errors) {
              let count = 0;
              if (Array.isArray(this.errorsList)) {
                for (const list of this.errorsList) {
                  if (list.message == err.Message) {
                    count += 1;
                  } else {
                    count = 0;
                  }
                }
              }
              if (count == 0 && err.Message) {
                  this.errorsList.push(err.Message);
              }
            }
            this.invalidIssuer = true;
          } else {
            this.errorsList = [];
            const loginData = data.LoginResponse;
            if (loginData.Status != 'ChangePassword') {
              sessionStorage.setItem('loginReq', JSON.stringify(loginData));
              sessionStorage.setItem('userToken', loginData.Token);
              this.service.loginData = loginData;
              this.service.defaultValue = loginData;
              this.service.userToken = loginData.Token;
              this.invalidIssuer = false;
              const userType = loginData.UserType;
             if (userType =='admin') {
               const menuSection = 'openCoverMenu'
                    sessionStorage.setItem('menuSection', 'openCoverMenu');
                    sessionStorage.setItem('productData', JSON.stringify(loginData));
                    this.router.navigate(['auth/products']);
                    console.log('Usetypeeeeee', userType);
              }
              if (userType !='admin') {
                sessionStorage.setItem('productData', JSON.stringify(loginData));
                sessionStorage.setItem('menuSection','navMenu');
                this.router.navigate(['auth/products']);
              }
            } else {
              sessionStorage.setItem('passChangeLogin', uname);
              this.router.navigate(['/changePasswordAction']);
            }
          }
        },
        error => {
          console.log('Error: ', error.message); });
  }
  brokerType() {
    this.brokerLogin = true;
    this.issuerLogin = false;
    this.brokerName = null;
    this.brokerPassword = null;
    this.invalidBroker = false;
    this.invalidIssuer = false;
  }
  issuerType() {
    this.brokerLogin = false;
    this.issuerLogin = true;
    this.invalidBroker = false;
    this.invalidIssuer = false;
  }
  open(errorList: any[]) {
    // console.log("Error List",errorList)
    // const dialogRef = this.dialog.open(ErrorModalComponent,
    //   {
    //     data: errorList
    //   },
    // );
  }
}
