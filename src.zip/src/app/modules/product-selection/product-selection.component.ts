
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { map, takeUntil, filter } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { AuthService } from '../../Auth/auth.service';
import { LoginService } from '../login/login.service';
import * as Mydatas from '../../app-config.json';
import { HttpService } from 'src/app/shared/Services/http.service';
import { SharedService } from 'src/app/shared/Services/shared.service';
@Component({
  selector: 'app-product-selection',
  templateUrl: './product-selection.component.html',
  styleUrls: ['./product-selection.component.scss'],
})
export class ProductSelectionComponent implements OnInit {
  public userDetails: any;productList:any[]=[];
  userMenu = [{ title: 'Profile' }, { title: 'Log out' }];
  currentTheme = 'default';loginId:any;branchValue:any;
  userPictureOnly: boolean = false;user: any;userResponse:any;
  title:string="Log out";
  public AppConfig: any = (Mydatas as any).default;
  public ApiUrl1: any = this.AppConfig.ApiUrl1;
  public CommonApiUrl: any = this.AppConfig.CommonApiUrl;
  private destroy$: Subject<void> = new Subject<void>();
  section=false;
  constructor(private router: Router,
    private authService: AuthService,
    private loginService:LoginService,
    private service: HttpService,private SharedService:SharedService) {
    this.userDetails = JSON.parse(sessionStorage.getItem('Userdetails'));
    this.userResponse = this.userDetails?.Result;
    this.loginId = this.userDetails.Result.LoginId;
    this.productList = this.userDetails.Result.BrokerCompanyProducts;
  }

  ngOnInit(): void {
    // this.userService.getUsers()
    // .pipe(takeUntil(this.destroy$))
    // .subscribe((users: any) => this.user = users.nick);

  // const { xl } = this.breakpointService.getBreakpointsMap();
  // this.themeService.onMediaQueryChange()
  //   .pipe(
  //     map(([, currentBreakpoint]) => currentBreakpoint.width < xl),
  //     takeUntil(this.destroy$),
  //   )
  //   .subscribe((isLessThanXl: boolean) => this.userPictureOnly = isLessThanXl);

  // this.themeService.onThemeChange()
  //   .pipe(
  //     map(({ name }) => name),
  //     takeUntil(this.destroy$),
  //   )
  //   .subscribe(themeName => this.currentTheme = themeName);

  //   this.menuService.onItemClick()
  //   .pipe(
  //     filter(({ tag }) => tag === 'my-context-menu'),
  //     map(({ item: { title } }) => title),
  //   )
  //   .subscribe((title: any) => {
  //     if (title === 'Log out') {
  //       sessionStorage.clear();
  //       this.authService.logout();

  //       this.router.navigate(['/login']);
  //     }
  //   });
  }

  onSelectProduct(item: any) {
    let userDetails = JSON.parse(sessionStorage.getItem('Userdetails'));
    userDetails.Result['ProductId'] = item.ProductId;
    console.log('ppppppp',item.ProductId)
    userDetails.Result['PackageYn'] = item.PackageYn;
    sessionStorage.setItem('Userdetails', JSON.stringify(userDetails));
    console.log("Products",item,userDetails.Result)
     this.router.navigate(['/Home']);

    // else if(item.ProductId =='4') this.router.navigate(['/Travel']);
    // //else if(item.ProductId=='7') this.router.navigate(['/HomeIns']);
    // else if(item.ProductId=='3') this.router.navigate(['/HomeIns']);
  }
  onLog(title)
  {
    if (title === 'Log out') {
      //sessionStorage.clear();
      //this.authService.logout();

      //this.router.navigate(['/login']);
      let Req = {
        "LoginId": this.loginId,
        "Token": this.loginService.getToken()
      };
      const urlLink = `${this.CommonApiUrl}authentication/logout`;
      this.SharedService.onPostMethodSync(urlLink, Req).subscribe(
        (data: any) => {
          let res:any = data;
          console.log(data);
          if (data.Result) {
            sessionStorage.clear();
            this.authService.logout();
            this.router.navigate(['/login']);

            console.log('You are logged out');

          }
            //
        });

    }
  }
}
