import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import * as Mydatas from '../../../../../app-config.json';
import { Router } from '@angular/router';
import { SharedService } from '../../../../../shared/shared.service';
import { DatePipe } from '@angular/common';
import { UpdateCustomerDetailsComponent } from '../../update-customer-details.component';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { CoverDetailsComponent } from '../cover-details/cover-details.component';
import { MatDialog } from '@angular/material/dialog';
@Component({
  selector: 'app-travel-quote-details',
  templateUrl: './travel-quote-details.component.html',
  styleUrls: ['./travel-quote-details.component.scss']
})
export class TravelQuoteDetailsComponent implements OnInit {

  @Input('quoteRefNo') quoteRefNo: any;
  @Input('travelDetails') travelDetails: any;
  @Output('getBack') getBack = new EventEmitter();
  @Output('onWishListProceed') onWishListProceed = new EventEmitter();
  searchList:any[]=[];customerHeader:any[]=[];customerData:any[]=[];
  addSection:boolean = false;customerData2:any[]=[];customerHeader2:any[]=[];
  title: any;clientName: any;dateOfBirth: any;productValue:any;
  emailId: any;mobileNo: any;idNumber: any;productList:any[]=[];
  travelsList:any[]=[];minDate:Date;kidSection:boolean = false;
  adultSection:boolean = false;seniorSection:boolean = false;
  public AppConfig: any = (Mydatas as any).default;
  public ApiUrl1: any = this.AppConfig.ApiUrl1;
  public CommonApiUrl: any = this.AppConfig.CommonApiUrl;ageList:any[]=[];
  public motorApiUrl:any = this.AppConfig.MotorApiUrl;
  countryList:any[]=[];referenceNo: any=null;travelGroupList:any[]=[];
  customerHeader3:any[]=[];noOfDays:any;
  currencyList:any[]=[];planList:any []=[];exchangeRate:any;productId:any;commissionValue:any="";
  userDetails:any;currencyCode:any;endDate:any;applicationId:any;executiveValue:any="";
  loginId:any;userType:any;agencyCode:any;branchCode:any;insuranceId:any;customerDetails:any;
  endMinDate: Date;adminSection:boolean = false;issuerSection:false;public TravelForm: FormGroup;
  maxDate: Date;travelId:any;travelName:any;premiumList:any;travelStartDate:any;grandSeniorEndAge:any;
  travelEndDate: any;customerDatas:any;subuserType:any;executiveSection:boolean = false;
  kidStartAge: any;kidEndAge: any;brokerbranchCode:any;superSeniorSection:boolean = false;
  adultStartAge: any;adultEndAge: any;seniorStartAge: any;seniorEndAge: any;grandSeniorStartAge:any;
  BelongingCountryId: any;brokerCode:any;brokerLoginId:any;superSeniorStartAge:any;
  executiveList: any[]=[];commissionTypeList:any[]=[];superSeniorEndAge:any;grandSeniorSection:boolean = false;
  PlanList:any[]=[];benefitList:any[]=[];
  questionSection:boolean=true;uwQuestionList:any[]=[];
  requestReferenceNo: string;

  constructor(private router:Router,private updateComponent:UpdateCustomerDetailsComponent,
    private sharedService:SharedService ,private datePipe:DatePipe
    ,public dialogService: MatDialog,private updateCustomerComponent:UpdateCustomerDetailsComponent) {

    this.userDetails = JSON.parse(sessionStorage.getItem('Userdetails'));
    console.log("UserDetails",this.userDetails);
    this.loginId = this.userDetails.Result.LoginId;
    this.userType = this.userDetails?.Result?.UserType;
    this.agencyCode = this.userDetails.Result.OaCode;
    this.brokerbranchCode = this.userDetails.Result.BrokerBranchCode;
    this.branchCode = this.userDetails.Result.BranchCode;
    this.productId = this.userDetails.Result.ProductId;
    this.insuranceId = this.userDetails.Result.InsuranceId;
    if(this.userType!='Broker'){
      let quoteStatus = sessionStorage.getItem('QuoteStatus');
      if(quoteStatus=='AdminRP'){
        this.adminSection = true;this.issuerSection = false;
      }
    }
    else{
      this.subuserType = sessionStorage.getItem('typeValue');
    }
    this.ageDropdown();
    this.createForm();

    let quoteRefNo = sessionStorage.getItem('quoteReferenceNo');
  if(quoteRefNo) this.requestReferenceNo = quoteRefNo;

  //this.getUWDetails();
   }

  ngOnInit(): void {
    this.getUWDetails();
  }
  public createForm() {

    this.TravelForm = new FormGroup({
      PlanTypeId: new FormControl('', Validators.required),
      SourceCountry: new FormControl(''),
      SectionId: new FormControl(''),
      HavePromoCode: new FormControl('N', Validators.required),
      PromoCode: new FormControl('', Validators.required),
      SportsCoverYn: new FormControl('N',Validators.required),
      TerrorismCoverYn: new FormControl('N', Validators.required),
      CovidCoverYn: new FormControl('N', Validators.required),
      TravelGroupDetails1:new FormControl('0'),
      TravelGroupDetails2:new FormControl('0'),
      TravelGroupDetails3:new FormControl('0'),
      TravelGroupDetails4:new FormControl('0'),
      TravelGroupDetails5:new FormControl('0'),
      travelStartDate: new FormControl(''),
      travelEndDate: new FormControl(''),
      Currency: new FormControl('Y', Validators.required),
      ExchangeRate: new FormControl('', Validators.required),
    });
  }
  setValues(customerDatas){
            this.travelName=customerDatas.travelName;
            this.BelongingCountryId = customerDatas.CountryId;
            this.executiveValue = customerDatas?.AcExecutiveId;
            this.commissionValue = customerDatas?.CommissionType;
            this.TravelForm.controls['PlanTypeId'].setValue(customerDatas.PlanTypeId);
            this.TravelForm.controls['SourceCountry'].setValue(customerDatas.DestinationCountry);
            this.TravelForm.controls['SectionId'].setValue(customerDatas.SectionId);
            this.TravelForm.controls['HavePromoCode'].setValue(customerDatas.HavePromoCode);
            this.TravelForm.controls['PromoCode'].setValue(customerDatas.PromoCode);
            this.TravelForm.controls['SportsCoverYn'].setValue(customerDatas.SportsCoverYn);
            this.TravelForm.controls['TerrorismCoverYn'].setValue(customerDatas.TerrorismCoverYn);
            this.TravelForm.controls['CovidCoverYn'].setValue(customerDatas.CovidCoverYn);
            let passengerDetails = customerDatas.GroupDetails;
            if(passengerDetails.length!=0){
              for(let passenger of passengerDetails){
                let entry = this.travelGroupList.filter(ele=>ele.GroupId==passenger.GroupId);
                console.log("Entryyyyyyy",entry)
                if(entry){
                  entry[0].GroupMembers = passenger.GroupMembers
                }
              }
            }
          //  this.TravelForm.controls['travelStartDate'].setValue(customerDatas.TravelStartDate);
          //  this.TravelForm.controls['travelEndDate'].setValue(customerDatas.TravelEndDate);
  }
  ageDropdown(){
    let ReqObj = {
      "InsuranceId":this.insuranceId,
    "BranchCode":this.branchCode,
    "ProductId":"4"
    }
    let urlLink = `${this.CommonApiUrl}master/dropdown/productgroup`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        console.log(data);
        if(data.Result){
           this.ageList = data.Result;
           if(this.ageList.length!=0){
            let i=0;
            for(let age of this.ageList){
               let entry = { "GroupId": age.Code,"GroupMembers":"0", "GroupDesc": age.CodeDesc };
               this.travelGroupList.push(entry)
               i+=1;
               if(i==this.ageList.length) this.planType();
            }
          }
          else{
            this.planType();
          }

        }
      },
      (err) => { },
    );
  }
  planType(){
    let ReqObj = {
      "InsuranceId":this.insuranceId,
      "BranchCode": this.branchCode
    }
    let urlLink = `${this.CommonApiUrl}dropdown/plantype`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        console.log(data);
        if(data.Result){
            this.planList = data.Result;

            this.getCountryList();
        }

      },
      (err) => { },
    );
  }
  getCountryList(){
    let ReqObj = {
      "InsuranceId": this.insuranceId,
      "BranchCode": this.branchCode
    }
    let urlLink = `${this.CommonApiUrl}master/dropdown/nationality`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        console.log(data);
        if(data.Result){
           this.countryList = data.Result;
           this.premiunDropdown();

        }
      },
      (err) => { },
    );
  }
  premiunDropdown(){
    let ReqObj = {
      "InsuranceId": this.insuranceId,
      "ProductId":"4",
    }
    let urlLink = `${this.ApiUrl1}master/dropdown/productsection`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        console.log(data);
        if(data.Result){
           this.premiumList = data.Result;
           if(this.travelDetails){
            this.setValues(this.travelDetails);
          }
        }
      },
      (err) => { },
    );
  }
  viewplanBenifits(){
    let ReqObj = {
      "PlanTypeId":this.TravelForm.controls['PlanTypeId'].value,
      //"PolicyTypeId":this.TravelForm.controls[''].value,
      //"PolicyTypeId":this.TravelForm.controls['PlanTypeId'].value,
      "PolicyTypeId":this.TravelForm.controls['SectionId'].value
    }
    let urlLink = `${this.motorApiUrl}api/gettravelpolicytype`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        if(data.Result){
          const dialogRef = this.dialogService.open(CoverDetailsComponent,{
            data: {
              titles: 'travel PolicyDetails',
              benefitList:data.Result
            }
          });
    
          dialogRef.afterClosed().subscribe(result => {
            console.log(`Dialog result: ${result}`);
          });
        }
      },

      (err) => { },
    );
  }
  onchangeContents(type,index){
    if(type=='sub'){
      this.travelGroupList[index].GroupMembers = String(Number(this.travelGroupList[index].GroupMembers)-1);
    }
    else{
      this.travelGroupList[index].GroupMembers = String(Number(this.travelGroupList[index].GroupMembers)+1);
    }
  }
  onSave(){
    let travelList=[];
    let totalPassengers = 0;
    travelList = this.travelGroupList.filter(ele=>ele.GroupMembers!='0');
    console.log("Filtered List",travelList)
    if(travelList.length!=0){
      let i=0;
      for(let travel of travelList){
          totalPassengers = totalPassengers+Number(travel.GroupMembers);
          i+=1;
          if(i==travelList.length){
            this.onFormSubmit(travelList,totalPassengers);
          }

          /*else{
            this.onFinalProceed();
          }*/
      }
    }
  }
  onFormSubmit(travelList,totalPassengers){
    let createdBy="";
    createdBy = this.loginId;
      this.brokerCode = this.agencyCode;
      this.brokerLoginId = createdBy;
      this.subuserType = sessionStorage.getItem('typeValue');
      this.applicationId = "01";
  let appId = "1",loginId="",brokerbranchCode="";
  let acExecutiveId = "", commissionType="";
  if(this.userType!='Issuer'){
    appId = "1"; loginId = this.loginId;
    brokerbranchCode = this.brokerbranchCode;
    acExecutiveId = this.executiveValue;
    commissionType = this.commissionValue;
  }
  else{
    appId = this.loginId;
    brokerbranchCode = null;
  }
  let currencyCode = null,exchangeRate =null, startDate=null,endDate=null,noOfDays=null;
  if(this.updateComponent.CurrencyCode){
    currencyCode = this.updateComponent.CurrencyCode
  }
  if(this.updateComponent.exchangeRate){
    exchangeRate = this.updateComponent.exchangeRate
  }
  if(this.updateComponent.travelStartDate){
    startDate = this.updateComponent.travelStartDate
  }
  if(this.updateComponent.travelEndDate){
    endDate = this.updateComponent.travelEndDate
  }
  if(this.updateComponent.noOfDays){
    noOfDays = this.updateComponent.noOfDays
  }

    let ReqObj = {

      "AcExecutiveId": acExecutiveId,
      "CommissionType": commissionType,
      "BrokerCode": this.brokerCode,
      "LoginId": createdBy,
      "SubUserType": this.subuserType,
      "ApplicationId": this.applicationId,
      "CustomerReferenceNo": sessionStorage.getItem('customerReferenceNo'),
      "RequestReferenceNo": this.quoteRefNo,
      "BranchCode": this.branchCode,
      "ProductId": this.productId,
       "UserType": this.userType,
      "BrokerBranchCode":this.brokerbranchCode,
      "BdmCode": "",
      "CreatedBy":this.loginId,
       "CustomerCode": null,
      "InsuranceId": this.insuranceId,
       "SourceType": null,
     "SectionId": this.TravelForm.controls['SectionId'].value,
      "TravelCoverId": this.TravelForm.controls['SectionId'].value,
        "Currency": currencyCode,
       "ExchangeRate": exchangeRate,
        "PlanTypeId": this.TravelForm.controls['PlanTypeId'].value,
        "SourceCountry":"TZA",
       "DestinationCountry": this.TravelForm.controls['SourceCountry'].value,
         "TotalPassengers": totalPassengers,
        "TravelId": "1",
        "HavePromoCode": this.TravelForm.controls['HavePromoCode'].value,
         "PromoCode": this.TravelForm.controls['PromoCode'].value,
        "SportsCoverYn":this.TravelForm.controls['SportsCoverYn'].value,
        "TerrorismCoverYn": this.TravelForm.controls['TerrorismCoverYn'].value,
        "CovidCoverYn": this.TravelForm.controls['CovidCoverYn'].value,
        "TravelCoverDuration": noOfDays,
        "TravelEndDate": this.travelStartDate,
        "TravelStartDate": this.travelEndDate,
        "GroupDetails": travelList
    }
    ReqObj['TravelStartDate'] = this.datePipe.transform(startDate, "dd/MM/yyyy");
    ReqObj['TravelEndDate'] = this.datePipe.transform(endDate, "dd/MM/yyyy");
    let urlLink = `${this.motorApiUrl}api/savetraveldetails`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        let res:any = data;
        if(data.ErrorMessage.length!=0){
          if(res.ErrorMessage){
            // for(let entry of res.ErrorMessage){
            //   let type: NbComponentStatus = 'danger';
            //   const config = {
            //     status: type,
            //     destroyByClick: true,
            //     duration: 4000,
            //     hasIcon: true,
            //     position: NbGlobalPhysicalPosition.TOP_RIGHT,
            //     preventDuplicates: false,
            //   };
            //   this.toastrService.show(
            //     entry.Field,
            //     entry.Message,
            //     config);
            // }
          }
        }
        else{
          /*let type: NbComponentStatus = 'success';
              const config = {
                status: type,
                destroyByClick: true,
                duration: 4000,
                hasIcon: true,
                position: NbGlobalPhysicalPosition.TOP_RIGHT,
                preventDuplicates: false,
              };
              this.toastrService.show(
                'Travel Details',
                'Travel Details Inserted/Updated Successfully',
                config)*/
                let entry = data?.Result;
                entry['TravelStartDate'] =  ReqObj?.TravelStartDate;
                entry['TravelEndDate'] =  ReqObj?.TravelEndDate;
                entry['TotalPassengers'] = ReqObj?.TotalPassengers;
                entry['SectionId'] = ReqObj?.SectionId;
                entry['Currency'] = ReqObj?.Currency;
                entry['DestinationCountry'] = data?.Result?.DestinationCountryDesc;
                entry['NoofDays'] = ReqObj?.TravelCoverDuration;
                this.requestReferenceNo = data.Result.RequestReferenceNo;
                this.onFinalProceed(entry);

              

        }
      },
      (err) => { },
    );
  }
  getCoverList(coverListObj){
    this.currencyCode = coverListObj?.Currency;
    let createdBy = this.loginId
    let groupList = coverListObj?.GroupDetails;
    let vehicleList = [];
    if(groupList.length!=0){
      let i=0;
      for(let group of groupList){
        let ReqObj ={
          "InsuranceId": this.insuranceId,
          "BranchCode": this.branchCode,
          "AgencyCode": this.agencyCode,
          "SectionId": coverListObj?.SectionId,
          "ProductId": this.productId,
          "MSRefNo": coverListObj?.MSRefNo,
          "VehicleId": group.TravelId,
          "CdRefNo": coverListObj?.CdRefNo,
          "VdRefNo": coverListObj?.VdRefNo,
          "CreatedBy": createdBy,
          "productId": this.productId,
          "Passengers":group.GroupMembers,
          "RequestReferenceNo": coverListObj?.RequestReferenceNo
        }
        let urlLink = `${this.CommonApiUrl}calculator/calc`;
        this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
          (data: any) => {
            let entry = data;

            entry['DestinationCountry'] = coverListObj.DestinationCountry;
            entry['TravelStartDate'] = coverListObj.TravelStartDate;
            entry['TravelEndDate'] = coverListObj.TravelEndDate;
            let groupEntry = groupList.filter(ele=>ele.GroupId==data?.VehicleId);
            if(groupEntry){
              entry['Passengers'] = groupEntry[0].GroupMembers;
              entry['TravelId'] = entry.VehicleId;
            }
            vehicleList.push(entry);
            i+=1;
            console.log("iiiiiiiii ",i)
            if(i==groupList.length){
              console.log("grouppppppppppppppppppp");
              sessionStorage.setItem('quoteReferenceNo',coverListObj.RequestReferenceNo)
            this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/excess-discount']);
              // this.vehicleDetailsList = vehicleList;
              // console.log("Final Vehicle Details",vehicleList);
              // this.checkSelectedCovers();

            }
          },
          (err) => { },
        );
      }
    }

  }


  getUWDetails(){
    let ReqObj = {
    "Limit":"0",
    "Offset":"100",
    "ProductId": this.productId,
    "LoginId": this.loginId,
    "InsuranceId": this.insuranceId,
    "BranchCode": this.branchCode
    }
    let urlLink = `${this.CommonApiUrl}master/getactiveuwquestions`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        let res:any = data.Result;
        if(res.length!=0){
          this.uwQuestionList = res;
          this.getEditUwQuestions();
        }
        else{
          //this.getCurrencyList();
        }
      },
      (err) => { },
    );
  }


  getEditUwQuestions(){
    let ReqObj = {
      "InsuranceId": this.insuranceId,
      "ProductId": this.productId,
      "LoginId": this.loginId,
      "RequestReferenceNo": this.requestReferenceNo,
      "VehicleId": "1"
    }
    let urlLink = `${this.CommonApiUrl}api/getuwquestionsdetails`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        let uwList = data?.Result;
        if(uwList.length!=0){
          let i=0;
          for(let ques of uwList){
            let entry = this.uwQuestionList.find(ele=>ele.UwQuestionId == ques.UwQuestionId);
            if(entry){ entry.Value = ques.Value};
            i+=1;
            if(i==uwList.length){
              this.uwQuestionList.forEach(x =>  {
                x.Value = x.Value ? '' || 'N' : 'N'
             });
              this.questionSection = true; console.log("Final UW List",this.uwQuestionList); /*this.getCurrencyList();*/}
          }
        }
        else{
          this.uwQuestionList.forEach(x =>  {
            x.Value = x.Value ? '' || 'N' : 'N'
         });
         console.log("Final UW List",this.uwQuestionList);
          this.questionSection = true;
          //this.getCurrencyList();
        }
      },
      (err) => { },
    );
  }
  onSaveUWQues(uwList,entry){
    if(uwList.length!=0){
      let urlLink = `${this.CommonApiUrl}api/saveuwquestions`;
      this.sharedService.onPostMethodSync(urlLink, uwList).subscribe(
        (data: any) => {
          if(data.Result){
            this.getCoverList(entry);
              //this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/excess-discount']);
          }
        },
        (err) => { },
      );
    }
  }

  onFinalProceed(entry){
    /*let i=0,j=0;
    for(let veh of this.travelDetails){
      let refNo = veh?.MSRefNo;
      if(refNo == undefined){
        i+=1;
      }
      j+=1;
      if(j==this.travelDetails.length){
        console.log("Final I",i)
        if(i==0){
          sessionStorage.setItem('travelDetailsList',JSON.stringify(this.travelDetails));
          if(this.uwQuestionList.length!=0){
            let i = 0;
            let uwList:any[]=[];
            for(let ques of this.uwQuestionList){
              ques['BranchCode'] = this.branchCode;
              let createdBy="";
                let quoteStatus = sessionStorage.getItem('QuoteStatus');
                if(quoteStatus=='AdminRP'){
                    createdBy = this.travelDetails[0].CreatedBy;
                }
                else{
                  createdBy = this.loginId;
                }
              if(ques.QuestionType == '01'){

                ques['CreatedBy'] = createdBy;
                ques['RequestReferenceNo'] = this.requestReferenceNo;
                ques['UpdatedBy'] = this.loginId;
                //ques["VehicleId"] = this.vehicleId
                uwList.push(ques);
              }
              else if(ques.Value!=""){
                ques['CreatedBy'] = createdBy;
                ques['RequestReferenceNo'] = this.requestReferenceNo;
                ques['UpdatedBy'] = this.loginId;
                //ques["VehicleId"] = this.vehicleId
                uwList.push(ques);
              }
              i+=1;
              if(i==this.uwQuestionList.length) this.onSaveUWQues(uwList);
            }
          }
          else{
            this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/excess-discount']);
          }

        }
        else{
          console.log("Redirecting to Save Data");
          //this.saveExistData();
        }
      }
    }*/

    if(this.uwQuestionList.length!=0){
      let i = 0;
      let uwList:any[]=[];
      for(let ques of this.uwQuestionList){
        ques['BranchCode'] = this.branchCode;
        let createdBy="";
          let quoteStatus = sessionStorage.getItem('QuoteStatus');
          if(quoteStatus=='AdminRP'){
              createdBy = this.travelDetails[0].CreatedBy;
          }
          else{
            createdBy = this.loginId;
          }
        if(ques.QuestionType == '01'){

          ques['CreatedBy'] = createdBy;
          ques['RequestReferenceNo'] = this.requestReferenceNo;
          ques['UpdatedBy'] = this.loginId;
          ques["VehicleId"] ="1"
          uwList.push(ques);
        }
        else if(ques.Value!=""){
          ques['CreatedBy'] = createdBy;
          ques['RequestReferenceNo'] = this.requestReferenceNo;
          ques['UpdatedBy'] = this.loginId;
          ques["VehicleId"] ="1"
          uwList.push(ques);
        }
        i+=1;
        if(i==this.uwQuestionList.length) this.onSaveUWQues(uwList,entry);
        //this.getCoverList('direct');
      }
    }
    else{
      this.getCoverList(entry);
      //this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/excess-discount']);
    }

  }

}
