import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SharedService } from '../../../../../shared/shared.service';
import { UpdateCustomerDetailsComponent } from '../../update-customer-details.component';
import { DatePipe } from '@angular/common';
import * as Mydatas from '../../../../../app-config.json';

@Component({
  selector: 'app-make-payement',
  templateUrl: './make-payement.component.html',
  styleUrls: ['./make-payement.component.css']
})
export class MakePayementComponent implements OnInit {
  
  public AppConfig: any = (Mydatas as any).default;
  public ApiUrl1: any = this.AppConfig.ApiUrl1;
  public CommonApiUrl: any = this.AppConfig.CommonApiUrl;
  public motorApiUrl:any = this.AppConfig.MotorApiUrl;
  activeMenu:any;
  Menu:any;
  first:boolean=false;Fifth:boolean=false;
  second:boolean=false;Fourth:boolean=false;
  Third: boolean;currencyCode:any;
  minDate: Date;
  customerDetails: any;
  vehicleDetails: any;
  requestReferenceNo: string;
  userDetails: any;
  loginId: any;
  userType: any;
  agencyCode: any;
  brokerbranchCode: any;
  branchCode: any;
  branchList: any;
  productId: any;
  insuranceId: any;
  subuserType: string;
  paymentTypeList: any[]=[];
  title: any;
  clientName: any;
  dateOfBirth: any;
  emailId: any;
  mobileNo: any;quoteNo:any;
  idNumber: any;quoteRefNo:any;
  vehicleList: any[]=[];totalPremium:any;
  policySection: boolean = false;yearlySection=false;nineMonthSection:boolean=false;
  sixMonthSection:boolean = false;threeMonthSection:boolean = false;
  policyNo: any;EmiYn:any="N";emiPeriod:any=null;emiMonth=null;
  customerType: string;Emilist1:any[]=[];emiSection:boolean = false;
  constructor(private router:Router,private sharedService: SharedService,
    private updateComponent:UpdateCustomerDetailsComponent,
   private datePipe:DatePipe) {
    this.minDate = new Date();
    this.customerDetails = JSON.parse(sessionStorage.getItem('customerDetails'));
    this.vehicleDetails = JSON.parse(sessionStorage.getItem('vehicleDetails'));
    let quoteRefNo = sessionStorage.getItem('quoteReferenceNo');
    if(quoteRefNo) this.requestReferenceNo = quoteRefNo;
    this.quoteNo = sessionStorage.getItem('quoteNo');
    this.userDetails = JSON.parse(sessionStorage.getItem('Userdetails'));
    console.log("User Details",this.userDetails)
    this.loginId = this.userDetails.Result.LoginId;
    this.userType = this.userDetails?.Result?.UserType;
    this.agencyCode = this.userDetails.Result.OaCode;
    this.brokerbranchCode = this.userDetails.Result.BrokerBranchCode;
    this.branchCode = this.userDetails.Result.BranchCode;
    this.branchList = this.userDetails.Result.LoginBranchDetails;
    this.productId = this.userDetails.Result.ProductId;
    this.subuserType = sessionStorage.getItem('typeValue');
    this.insuranceId = this.userDetails.Result.InsuranceId;
      let paymentId = sessionStorage.getItem('quotePaymentId');
      if(paymentId){
        this.getPaymentTypeList();
      }
  }

  ngOnInit(): void {
    if(this.customerDetails){
      this.title = this.customerDetails?.TitleDesc;
      this.clientName = this.customerDetails?.ClientName;
      this.dateOfBirth = this.customerDetails?.DobOrRegDate;
      this.emailId = this.customerDetails?.Email1;
      this.mobileNo = this.customerDetails?.MobileNo1;
      this.idNumber = this.customerDetails?.IdNumber;
      if(this.customerDetails.PolicyHolderType=='1'){this.customerType="Individual";}
      else if(this.customerDetails.PolicyHolderType=='2'){this.customerType="Corporate";}
    }
    this.getEditQuoteDetails();
  }
  getEditQuoteDetails(){
    let ReqObj = {
      "QuoteNo":this.quoteNo
    }
    let urlLink = `${this.CommonApiUrl}quote/viewquotedetails`;
    // let ReqObj = {
    //   "ProductId": this.productId,
    //   "RequestReferenceNo": this.requestReferenceNo
    // }
    // let urlLink = `${this.CommonApiUrl}api/view/calc`;
    this.sharedService.onPostMethodSync(urlLink, ReqObj).subscribe(
      (data: any) => {
          if(data?.Result){
            this.vehicleList = data?.Result?.ProductDetails;
            let quoteDetails = data?.Result?.QuoteDetails;
            this.totalPremium = quoteDetails?.OverallPremiumFc;
            this.currencyCode = quoteDetails?.Currency;
            if(quoteDetails.EmiYn!=null){
              this.EmiYn = quoteDetails.EmiYn;
              this.emiPeriod = quoteDetails.InstallmentPeriod;
              this.emiMonth = quoteDetails.InstallmentMonth;
              if(this.EmiYn=='Y') this.getCurrentEmiDetails();
            }
            else{
              this.EmiYn = "N";
              this.emiPeriod = null;
              this.emiMonth = null;
            }
          }
      },
      (err) => { },
    );

  }
  getCurrentEmiDetails(){
    let ReqObj = {
         "QuoteNo": this.quoteNo,
         "InsuranceId": this.insuranceId,
         "ProductId": this.productId
         }
    let urlLink = `${this.CommonApiUrl}api/getemidetailsbyquoteno`;
    this.sharedService.onPostMethodSync(urlLink, ReqObj).subscribe(
      (data: any) => {
          if(data?.Result){
              let emiList = data.Result;
              if(emiList.length!=0){
                    let i=0,yearlyList=[],nineList=[],sixList=[],threeList=[];
                    if(emiList.length==13){
                      this.yearlySection = true;
                      yearlyList = emiList;
                    }
                    else if(emiList.length==10){
                      nineList = emiList;
                      this.nineMonthSection = true;
                    }
                    else if(emiList.length==7){
                      sixList = emiList;
                      this.sixMonthSection = true;
                    }
                    else if(emiList.length==4){
                      threeList = emiList;
                      this.threeMonthSection = true;
                    }
                    this.setEmiTableValues(yearlyList,nineList,sixList,threeList);
                // this.Emilist1=data?.Result[0]?.EmiPremium
                // this.Emilist2=data?.Result[1]?.EmiPremium;
                // this.EmiDetails=data.Result[0].EmiDetails;
                // this.EmiDetails1=data.Result[1].EmiDetails;
                console.log('tttt',this.totalPremium);
              }
          }
        },
        (err) => { },
      );
  }
  setEmiTableValues(yearlyList,nineList,sixList,threeList){
    if(this.yearlySection){
       let i=0;this.Emilist1=[];
       for(let entry of yearlyList){
            let data = entry;
            if(yearlyList[i]){data['yearlyAmount']=yearlyList[i].InstallmentAmount}
            else{data['yearlyAmount']=null}
            if(nineList[i]){data['nineAmount']=nineList[i].InstallmentAmount}
            else{data['nineAmount']=null}
            if(sixList[i]){data['sixAmount']=sixList[i].InstallmentAmount}
            else{data['sixAmount']=null}
            if(threeList[i]){data['threeAmount']=threeList[i].InstallmentAmount}
            else{data['threeAmount']=null}
            this.Emilist1.push(entry);
            i+=1;
            if(i==yearlyList.length){this.emiSection=true}
       }
    }
    else if(this.nineMonthSection){
      let i=0;this.Emilist1=[];
      for(let entry of nineList){
           let data = entry;
           if(yearlyList[i]){data['yearlyAmount']=yearlyList[i].InstallmentAmount}
           else{data['yearlyAmount']=null}
           if(nineList[i]){data['nineAmount']=nineList[i].InstallmentAmount}
           else{data['nineAmount']=null}
           if(sixList[i]){data['sixAmount']=sixList[i].InstallmentAmount}
           else{data['sixAmount']=null}
           if(threeList[i]){data['threeAmount']=threeList[i].InstallmentAmount}
           else{data['threeAmount']=null}
           this.Emilist1.push(entry);
           i+=1;
           if(i==nineList.length){this.emiSection=true}
      }
   }
   else if(this.sixMonthSection){
      let i=0;this.Emilist1=[];
      for(let entry of sixList){
           let data = entry;
           if(yearlyList[i]){data['yearlyAmount']=yearlyList[i].InstallmentAmount}
           else{data['yearlyAmount']=null}
           if(nineList[i]){data['nineAmount']=nineList[i].InstallmentAmount}
           else{data['nineAmount']=null}
           if(sixList[i]){data['sixAmount']=sixList[i].InstallmentAmount}
           else{data['sixAmount']=null}
           if(threeList[i]){data['threeAmount']=threeList[i].InstallmentAmount}
           else{data['threeAmount']=null}
           this.Emilist1.push(entry);
           i+=1;
           if(i==sixList.length){this.emiSection=true}

      }
   }
   else if(this.threeMonthSection){
      let i=0;this.Emilist1=[];
      for(let entry of threeList){
           let data = entry;
           if(yearlyList[i]){data['yearlyAmount']=yearlyList[i].InstallmentAmount}
           else{data['yearlyAmount']=null}
           if(nineList[i]){data['nineAmount']=nineList[i].InstallmentAmount}
           else{data['nineAmount']=null}
           if(sixList[i]){data['sixAmount']=sixList[i].InstallmentAmount}
           else{data['sixAmount']=null}
           if(threeList[i]){data['threeAmount']=threeList[i].InstallmentAmount}
           else{data['threeAmount']=null}
           this.Emilist1.push(entry);
           i+=1;
           if(i==threeList.length){this.emiSection=true}
      }
   }
  }
  getTotalVehiclesCost(){
    let totalCost=0,i=0;
    console.log('VECGJKKK',this.vehicleList);
    for(let veh of this.vehicleList){
      if(veh?.OverallPremiumFc) totalCost = totalCost+Number(veh?.OverallPremiumFc);

      i+=1;
      if(i==this.vehicleList.length) this.totalPremium = totalCost;
    }
  }
  onRedirect(value:any){
    this.Menu=value;
    this.first = false;this.second = false;this.Third=false;this.Fourth=false;this.Fifth = false;
    if(this.Menu=='VisionPay'){ this.first=true;}
    else if(this.Menu=='Pos'){ this.second=true;}
    else if(this.Menu=='1'){ this.Third=true; }
    else if(this.Menu == '2'){ this.Fourth = true;}
    else if(this.Menu == 'Bank'){ this.Fifth = true;}
  }
  getPaymentTypeList(){
    let ReqObj = {
      "BranchCode": this.branchCode,
      "InsuranceId": this.insuranceId,
      "UserType": this.userType,
      "SubUserType": this.subuserType,
      "ProductId": this.productId
    }
    let urlLink = `${this.CommonApiUrl}master/dropdown/paymenttypes`;
     this.sharedService.onPostMethodSync(urlLink, ReqObj).subscribe(
      (data: any) => {
        console.log(data);
        if(data.Result){
          this.paymentTypeList = data.Result;
        } 
      },
      (err) => { },
      );
  }
  onCashPayment(){
    let ReqObj = {
      "CreatedBy": this.loginId,
      "InsuranceId": this.insuranceId,
      "EmiYn":"N",
      "Premium": this.totalPremium,
      "QuoteNo": this.quoteNo,
      "Remarks": "None",
      "SubUserType": this.subuserType,
      "UserType": this.userType,
      "PaymentType": this.activeMenu,
      "PaymentId": sessionStorage.getItem('quotePaymentId')
    }
    let urlLink = `${this.CommonApiUrl}payment/insertpaymentdetails`;
     this.sharedService.onPostMethodSync(urlLink, ReqObj).subscribe(
      (data: any) => {
        if(data.Result){
          if(data.Result.PolicyNo){
            this.policyNo = data.Result.PolicyNo;
            this.policySection = true;
          }
        } 
      },
      (err) => { },
      );
  }
}
