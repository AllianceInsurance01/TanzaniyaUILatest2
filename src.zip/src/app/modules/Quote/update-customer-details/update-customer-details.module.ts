import { UpdateCustomerDetailsComponent } from './update-customer-details.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule, DatePipe, DecimalPipe } from '@angular/common';
import { MAT_DATE_LOCALE, MatNativeDateModule } from '@angular/material/core';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgModule } from '@angular/core';
import {MatTabsModule} from '@angular/material/tabs';
import { UpdateCustomerDetailsRoutingModule } from './update-customer-details-routing.module';
import { CustomerDetailsComponent } from './Components/customer-details/customer-details.component';
import { InsuredDetailsComponent } from './Components/insured-details/insured-details.component';
import { PremiumDetailsComponent } from './Components/premium-details/premium-details.component';
import { ExcessDiscountComponent } from './Components/excess-discount/excess-discount.component';
import { MakePayementComponent } from './Components/make-payement/make-payement.component';
import { MaterialModule } from '../../../shared/material/material.module';
import { TablesModule } from '../../../shared/Tables/tables.module';
import { DirectivesModule } from '../../../shared/Directives/directives.module';
import { PipesModule } from '../../../shared/pipes/pipes.module';
import { DigitOnlyModule } from '@uiowa/digit-only';
import { MotorDetailsComponent } from './Components/motor-details/motor-details.component';
import { VehicleDetailsComponent } from './Components/vehicle-details/vehicle-details.component';
import { UnderWriterDetailsComponent } from './Components/under-writer-details/under-writer-details.component';
import { VehicleWishListComponent } from './Components/vehicle-wish-list/vehicle-wish-list.component';
import { TravelQuoteDetailsComponent } from './Components/travel-quote-details/travel-quote-details.component';
import { CoverDetailsComponent } from './Components/cover-details/cover-details.component';
import { DomesticQuoteDetailsComponent } from './Components/domestic-quote-details/domestic-quote-details.component';
import { TravelPassengerDetailsComponent } from './Components/travel-passenger-details/travel-passenger-details.component';
import { PersonalQuoteDetailsComponent } from './Components/personal-quote-details/personal-quote-details.component';
import { EmployersQuoteDetailsComponent } from './Components/employers-quote-details/employers-quote-details.component';
import { WorkmensQuoteDetailsComponent } from './Components/workmens-quote-details/workmens-quote-details.component';
//import { NewViewDetailsComponent } from './Components/new-view-details/new-view-details.component';
import { DomesticRiskDetailsComponent } from './Components/domestic-risk-details/domestic-risk-details.component';
import { FormlyModule } from '@ngx-formly/core';
import { FormlyFieldStepper } from 'src/app/stepper.type';
import { FormlyMaterialModule } from '@ngx-formly/material';
import { FormlyBootstrapModule } from '@ngx-formly/bootstrap';
import { FormlyMatDatepickerModule } from '@ngx-formly/material/datepicker';
import { FormlyMatToggleModule } from '@ngx-formly/material/toggle';
import { MultiSchemaTypeComponent } from './Components/FormlyComponents/multiSchemaType';
import { ObjectTypeComponent } from './Components/FormlyComponents/objectType';
import { ArrayTypeComponent } from './Components/FormlyComponents/arrayType';
import { NullTypeComponent } from './Components/FormlyComponents/nullType';
import { NgSelectFormlyComponent } from 'src/app/ngselect.type';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [
    UpdateCustomerDetailsComponent,
    CustomerDetailsComponent,
    InsuredDetailsComponent,
    VehicleDetailsComponent,
    PremiumDetailsComponent,
    ExcessDiscountComponent,
    MakePayementComponent,
    MotorDetailsComponent,
    UnderWriterDetailsComponent,
    CoverDetailsComponent,
    VehicleWishListComponent,
    TravelQuoteDetailsComponent,
    DomesticQuoteDetailsComponent,
    TravelPassengerDetailsComponent,
    DomesticRiskDetailsComponent,
    PersonalQuoteDetailsComponent,
    EmployersQuoteDetailsComponent,
    WorkmensQuoteDetailsComponent,
    MultiSchemaTypeComponent,
    ObjectTypeComponent,
    ArrayTypeComponent,
    NullTypeComponent
    //NewViewDetailsComponent

    ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DirectivesModule,
    NgSelectModule,
    UpdateCustomerDetailsRoutingModule,
    TablesModule,
    MaterialModule,
    PipesModule,
    DigitOnlyModule,
    NgbModule,
    MatTabsModule,
    FormlyModule.forRoot({
      validationMessages: [{ name: 'required', message: 'This field is required' }],
      types: [
        { name: 'stepper', component: FormlyFieldStepper, wrappers: [] },
        { name: 'null', component: NullTypeComponent, wrappers: ['form-field'] },
        { name: 'array', component: ArrayTypeComponent },
        { name: 'object', component: ObjectTypeComponent },
        { name: 'multischema', component: MultiSchemaTypeComponent },
        {
          name: 'my-autocomplete',
          component: NgSelectFormlyComponent
        },
        {
          name: 'string',
          extends: 'input'
        },
        {
          name: 'number',
          extends: 'input',
          defaultOptions: {
            templateOptions: {
              type: 'number'
            }
          }
        },
        {
          name: 'date',
          extends: 'input',
          defaultOptions: {
            templateOptions: {
              type: 'datepicker'
            }
          }
        }
      ],
		  }),
    FormlyMaterialModule,
    FormlyBootstrapModule,
    MatNativeDateModule,
    FormlyMatDatepickerModule,
		FormlyMatToggleModule,
  ],

  providers: [DatePipe, { provide: MAT_DATE_LOCALE, useValue: 'en-GB' }],
  bootstrap: [UpdateCustomerDetailsComponent],
})
export class UpdateCustomerDetailsModule {}
