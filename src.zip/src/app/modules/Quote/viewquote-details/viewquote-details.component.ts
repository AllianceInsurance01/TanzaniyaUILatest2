import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, NavigationStart, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import * as Mydatas from '../../../app-config.json';
import { SharedService } from '../../../shared/shared.service';

@Component({
  selector: 'app-viewquote-details',
  templateUrl: './viewquote-details.component.html',
  styleUrls: ['./viewquote-details.component.css']
})
export class VieQuoteDetailsComponent implements OnInit {
  ngOnInit(): void {

  }
}
