
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ReferralPendingComponent } from './ReferralCases/referral-pending/referral-pending.component';
import { ReferralRejectedComponent } from './ReferralCases/referral-rejected/referral-rejected.component';
import { ReferralApprovedComponent } from './ReferralCases/referral-approved/referral-approved.component';

const routes: Routes = [
  {
    path: '',
    redirectTo:'referralPending'
    
  },
  
  {
    path: 'referralPending',
    component: ReferralPendingComponent,
    data: {
      preload: true,
      title: "Referral Pending Quotes",
      breadcrumb: 'Referral Pending Quotes',
    }
  },
  {
    path: 'referralRejected',
    component: ReferralRejectedComponent,
    data: {
      preload: true,
      title: "Referral Rejected Quotes",
      breadcrumb: 'Referral Rejected Quotes',
    }
  },
  {
    path: 'referralApproved',
    component: ReferralApprovedComponent,
    data: {
      preload: true,
      title: "Referral Approved Quotes",
      breadcrumb: 'Referral Approved Quotes',
    }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdminRoutingModule {}
