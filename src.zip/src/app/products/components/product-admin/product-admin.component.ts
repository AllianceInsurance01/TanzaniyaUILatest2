import { Component, OnInit } from '@angular/core'
import { ProductData } from '../../models/product'
import { ProductService } from '../../service/product.service'
import { Router } from '@angular/router'

@Component({
	selector: 'app-product-admin',
	templateUrl: './product-admin.component.html',
	styleUrls: ['./product-admin.component.scss'],
})
export class ProductAdminComponent implements OnInit {
	public products: ProductData[] = []
	public displayedColumns: string[] = ['id', 'name', 'price', 'CreatedBy','Status','actions']
	public dataSource = null
	public CommonApiUrl: any = "http://192.168.1.42:8086/";
	userDetails: any
	loginId: any
	agencyCode: any
	branchCode: any
	productId: any
	insuranceId: any
	userType: any
	customerData: any[]=[];
	constructor(private productService: ProductService, private router: Router) {}

	ngOnInit(): void {
		console.log('dataSource: ', this.dataSource)
		this.getLoginDetails();
	}

	deleteProduct(productId: string): void {
		this.productService
			.deleteProduct(productId)
			.then((result) => {
				this.getProductData()
			})
			.catch((error) => {
				console.log(error)
			})
	}
	getLoginDetails(): void {
		let ReqObj = {
			"LoginId": "kalibroker2",
			"Password": "Admin@01",
			"ReLoginKey": "Y"
		}
		const urlLink = `${this.CommonApiUrl}authentication/login`;
		this.productService.onPostMethodBasicSync(urlLink, ReqObj).subscribe(
			(data: any) => {
			  let res:any = data;
			  console.log(data);
			  if (data.Result) {
				const Token = data?.Result?.Token;
				sessionStorage.setItem('Userdetails', JSON.stringify(data));
				sessionStorage.setItem('UserToken', Token);
				sessionStorage.setItem('menuSection', 'navMenu');
				this.userDetails = JSON.parse(sessionStorage.getItem('Userdetails'));
				this.loginId = this.userDetails.Result.LoginId;
				this.agencyCode = this.userDetails.Result.OaCode;
				this.branchCode = this.userDetails.Result.BranchCode;
				this.productId = this.userDetails.Result.ProductId;
				this.insuranceId = this.userDetails.Result.InsuranceId;
				this.userType = this.userDetails.Result.UserType;
				this.getCustomersList();
			}
		},
  
		(err: any) => { console.log(err); },
	  );
	  //this.router.navigate(['/Admin']);
	
	}
	onAddNew(){
		sessionStorage.removeItem('customerReferenceNo');
		this.router.navigate(['/admin/product'])
	}
	onEditCustomer(rowData){
		sessionStorage.setItem('customerReferenceNo',rowData.CustomerReferenceNo);
		this.router.navigate(['/admin/product'])
	}
	getCustomersList(){
		let appId = "1",loginId="",brokerbranchCode="";
		if(this.userType!='Issuer'){
		  appId = "1"; loginId = this.loginId;
		}
		else{
		  appId = this.loginId;
		}
		let ReqObj = {
		"BrokerBranchCode": "02",
		"InsuranceId":"100002",
		"ProductId": this.productId,
		"CreatedBy":this.loginId,
		"BranchCode": "02",
		"UserType": this.userType,
		"Limit":"0",
		"Offset":"100"
	  }
	  let urlLink = `${this.CommonApiUrl}api/getallcustomerdetails`;
	  this.productService.onPostMethodSync(urlLink, ReqObj).subscribe(
		(data: any) => {
		  console.log(data);
		  if(data.Result){
			  this.customerData = data?.Result;
		  }
  
		},
		(err) => { },
	  );
	}
	getProductData(): void {
		this.productService.getProducts().then((products: ProductData[]) => {
			console.log(products)
			this.products = products
			this.dataSource = products
		})
	}
}
