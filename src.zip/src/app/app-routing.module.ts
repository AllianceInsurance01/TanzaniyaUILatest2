import { NgModule } from '@angular/core'
import { Routes, RouterModule } from '@angular/router'
import { ProductListComponent } from './products/components/product-list/product-list.component'
import { ProductItemComponent } from './products/components/product-item/product-item.component'
import { ProductAdminComponent } from './products/components/product-admin/product-admin.component'
import { ProductFormComponent } from './products/components/product-form/product-form.component'
import { ProductSelectionComponent } from './modules/product-selection/product-selection.component'
import { BranchSelectionComponent } from './modules/branch-selection/branch-selection.component'
import { HomeLayoutComponent } from './layout/home-layout/home-layout.component'
import { AuthGuard } from './Auth/auth.guard'

const routes: Routes = [
	// {
	// 	path: '',
	// 	component: ProductAdminComponent,
	// },
	// {
	// 	path: 'product',
	// 	component: ProductItemComponent,
	// },
	// {
	// 	path: 'admin',
	// 	component: ProductAdminComponent,
	// },
	// {
	// 	path: 'admin/product',
	// 	component: ProductFormComponent,
	// },
	// {
	// 	path: '**',
	// 	redirectTo: '',
	// },
	{
		path: 'login',
		loadChildren: () => import('./modules/login/login.module').then(m => m.LoginModule),
	},
	{
		path:'branch',
		component:BranchSelectionComponent
	},
	{
		path: 'product',
		component: ProductSelectionComponent,
	},
	{
		path: '',
		component: HomeLayoutComponent,
		canActivate: [AuthGuard],
		children: [
	
		  {
			path: 'Home',
			loadChildren: () => import('./modules/dashboard/dashboard.module').then(m => m.DashboardModule),
			data: {
			  preload: true,
			  title: "Home",
			  breadcrumb: 'Home',
			}
		  },
		  {
			path: 'Admin',
			loadChildren: () => import('./modules/Admin/admin.module').then(m => m.AdminModule),
			data: {
			  preload: true,
			  title: "Admin",
			  breadcrumb: 'Admin',
			}
		  },
		]
	},
	{ path: '**', redirectTo: 'login' },
]

@NgModule({
	imports: [RouterModule.forRoot(routes)],
	exports: [RouterModule],
})
export class AppRoutingModule {}
