import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { FormlyFieldConfig } from '@ngx-formly/core';
import { FormlyJsonschema } from '@ngx-formly/core/json-schema';
import { FormGroup, FormControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import { ProductData } from '../models/product';
import * as Mydatas from '../../../../../app-config.json';
import { SharedService } from 'src/app/shared/Services/shared.service';
import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { tap } from "rxjs/operators";
export class ForceLengthValidators {
  static maxLength(maxLength: number) {
    return (control: FormControl): ValidationErrors => {
      if (!control.value) {
        return null;
      }

      if (control.value.length > maxLength) {
        //force the length to 
         control.setValue(control.value.substring(0, maxLength));
      }

      return null;
    };
  }
  static min(min: number): ValidatorFn {
    return (control: FormControl): { [key: string]: boolean } | null => {
    
      let val: number = control.value;
    
      if (control.pristine || control.pristine) {
        return null;
      }
      if (val >= min) {
        return null;
      }
      return { 'min': true };
      }
    }
}
@Component({
  selector: 'app-personal-quote-details',
  templateUrl: './personal-quote-details.component.html',
  styleUrls: ['./personal-quote-details.component.scss']
})
export class PersonalQuoteDetailsComponent implements OnInit {
  fields: any[]=[];
  public AppConfig: any = (Mydatas as any).default;
  public ApiUrl1: any = this.AppConfig.ApiUrl1;
  public motorApiUrl:any = this.AppConfig.MotorApiUrl;
  public commonApiUrl:any = this.AppConfig.CommonApiUrl;
  occupationList: any;userDetails: any;
  loginId: any;agencyCode: any;
  branchCode: any;productId: any;
  insuranceId: any;commonDetails: any;
  brokerbranchCode: any;branchList: any;
  userType: any;
  brokerCode: any;
  applicationId: string;
  subuserType: any=null;
  acExecutiveId: any = null;
  commissionType: any=null;
  customerDetails: any;
  requestReferenceNo: any=null;
  uwQuestionList: any[]=[];questionSection:boolean = false;
  dobminDate: Date;
  sourceType: any=null;
  customerCode: any=null;
  bdmCode: any=null;
  quoteDetails: any;
  issuerSection: boolean;
  constructor(private formlyJsonschema: FormlyJsonschema,private sharedService: SharedService,private datePipe:DatePipe,
    private router:Router, private http: HttpClient){
      this.customerDetails = JSON.parse(sessionStorage.getItem('customerDetails'));
      let commonDetails = JSON.parse(sessionStorage.getItem('homeCommonDetails'));
      if(commonDetails) this.commonDetails = commonDetails;
      this.userDetails = JSON.parse(sessionStorage.getItem('Userdetails'));
      this.loginId = this.userDetails.Result.LoginId;
      this.userType = this.userDetails?.Result?.UserType;
      this.agencyCode = this.userDetails.Result.OaCode;
      this.brokerbranchCode = this.userDetails.Result.BrokerBranchCode;
      this.branchCode = this.userDetails.Result.BranchCode;
      this.branchList = this.userDetails.Result.LoginBranchDetails;
      this.productId = this.userDetails.Result.ProductId;
      this.insuranceId = this.userDetails.Result.InsuranceId;
      this.getOccupationList();
      this.productItem = new ProductData();
      this.dobminDate = new Date();
  }
    
  countyList:any[]=[];public productItem: ProductData = null
  policyStartDate:any;
  DateOfBirth:any;
  FirstName:any;
  minDate:Date;
  maxDate:Date;
  activeMenu:any='menu1';
  BenifitList:any[]=[];public form = new FormGroup({})
	public model = {}
ngOnInit(): void {
  if(this.productId=='13'){
    this.fields =  [
      {
          fieldGroup: [
          {
            fieldGroupClassName: 'row',
            fieldGroup: [
            {
              className: 'col-4',
              type: 'input',
              key: 'CustomerName',
              props: {
              label: 'Insurer Name',
              required: true,
              options: [
               
              ],
              },
              
              expressions: {
              },
            },
            {
              className: 'col-4',
              key: 'Dob',
              type: 'date',
              props: {
              label: 'Date Of Birth(Choose Back Date )',
              required: true,
              type: 'date',
              datepickerOptions: {
                max: new Date(),
                },
              }
            },
            {
              className: 'col-4',
              type: 'select',
              key: 'OccupationType',
              props: {
              label: 'Occupation',
              required: true,
              options: [
              ],
              },
              expressions: {
              'props.disabled': '!model.CustomerName',
              },
            },
            {
              className: 'col-4',
              type: 'input',
              key: 'SalaryPerAnnum',
              
              props: {
              label: `Salary/Year (${this.commonDetails[0].Currency})`,
              required: true,
              options: [
               
              ],
              
              },
              validators: {
                validation: [ForceLengthValidators.maxLength(20), ForceLengthValidators.min(1)]
              },
              hooks: {
              onInit: (field: FormlyFieldConfig) => {
                field.formControl.valueChanges.subscribe(() => {
                  this.getSIValue();
                });
              },
              },
              expressions: {
              },
            },
            {
              className: 'col-4',
              type: 'select',
              key: 'BenefitCoverMonth',
              props: {
              label: 'Benefit Period',
              required: true,
              options: [
                { label: '12 Months', value: '12' },
                { label: '24 Months', value: '24' },
                { label: '36 Months', value: '36' },
              ],
              },
              hooks: {
                onInit: (field: FormlyFieldConfig) => {
                  field.formControl.valueChanges.subscribe(() => {
                    this.getSIValue();
                  });
                },
              },
              expressions: {
              'props.disabled': '!model.CustomerName',
              },
            },
            {
              className: 'col-4',
              type: 'input',
              key: 'SumInsured',
              props: {
              label: `SumInsured  (${this.commonDetails[0].Currency})`,
              required: true,
              options: [
               
              ],
              
              },
              validators: {
                validation: [ForceLengthValidators.maxLength(20), ForceLengthValidators.min(1)]
              },
              expressions: {
             
              },
            },
            ]
          }
          ],
      },
    ];
    console.log(JSON.stringify(this.fields))
  }
  else if(this.productId=='14'){
    this.fields=[
      {
        fieldGroup: [
          {
            fieldGroupClassName: 'row',
            fieldGroup: [
            {
              className: 'col-4',
              type: 'input',
              key: 'CustomerName',
              props: {
              label: 'Insurer Name',
              required: true,
              options: [
               
              ],
              },
              expressions: {
              },
            },
            {
              className: 'col-4',
              key: 'Dob',
              type: 'input',
              props: {
              label: 'Date Of Birth(Choose Back Date )',
              required: true,
              type: 'date',
              datepickerOptions: {
                max: new Date(),
                },
              }
            },
            {
              className: 'col-4',
              type: 'select',
              key: 'OccupationType',
              props: {
              label: 'Occupation',
              required: true,
              options: [
              ],
              },
              expressions: {
              'props.disabled': '!model.CustomerName',
              },
            },
            {
              className: 'col-4',
              type: 'input',
              key: 'SalaryPerAnnum',
              
              props: {
              label: `Salary/Year (${this.commonDetails[0].Currency})`,
              required: true,
              options: [
               
              ],
              },
              validators: {
                validation: [ForceLengthValidators.maxLength(20), ForceLengthValidators.min(1)]
              },
              hooks: {
              onInit: (field: FormlyFieldConfig) => {
                field.formControl.valueChanges.subscribe(() => {
                  this.getSIValue();
                });
              },
              },
              expressions: {
              },
            },
            {
              className: 'col-4',
              type: 'select',
              key: 'JobJoiningMonth',
              props: {
              label: 'Job Joined Year',
              required: true,
              options: [
                { label: '12 Months', value: '12' },
                { label: '24 Months', value: '24' },
                { label: '36 Months', value: '36' },
              ],
              },
              expressions: {
              'props.disabled': '!model.CustomerName',
              },
            },
            // {
            //   className: 'col-4',
            //   type: 'select',
            //   key: 'BetweenDiscontinued',
            //   props: {
            //   label: 'Between Discontinued?',
            //   required: true,
            //   options: [
            //     { label: '- Select -', value: '' },
            //     { label: 'Yes', value: 'Y' },
            //     { label: 'No', value: 'N' },
            //   ],
            //   },
              
            //   expressions: {
            //   'props.disabled': '!model.CustomerName',
            //   },
            // },
            // {
            //   className: 'col-4',
            //   type: 'select',
            //   key: 'EthicalWorkInvolved',
            //   props: {
            //   label: 'Involved in Unethical Work?',
            //   required: true,
            //   options: [
            //     { label: '- Select -', value: '' },
            //     { label: 'Yes', value: 'Y' },
            //     { label: 'No', value: 'N' },
            //   ],
            //   },
            //   expressions: {
            //   'hide': "model.BetweenDiscontinued!='Y'",
            //   },
            // },
            {
              className: 'col-4',
              type: 'input',
              key: 'SumInsured',
              props: {
              label: `Employee's SumInsured  (${this.commonDetails[0].Currency})`,
              required: true,
              options: [
               
              ],
              },
              validators: {
                validation: [ForceLengthValidators.maxLength(20), ForceLengthValidators.min(1)]
              },
              expressions: {
                
              },
            },
            ]
          }
          ],
      }
      
    ];
  }
  else if(this.productId=='15'){
    this.fields=[
      {
        fieldGroup: [
          {
            fieldGroupClassName: 'row',
            fieldGroup: [
            {
              className: 'col-4',
              type: 'input',
              key: 'CustomerName',
              props: {
              label: 'Insurer Name',
              required: true,
              options: [
               
              ],
              },
              expressions: {
              },
            },
            {
              className: 'col-4',
              key: 'Dob',
              type: 'input',
              props: {
              label: 'Date Of Birth(Choose Back Date )',
              required: true,
              type: 'date',
              datepickerOptions: {
                max: new Date(),
                },
              }
            },
            {
              className: 'col-4',
              type: 'select',
              key: 'OccupationType',
              props: {
              label: 'Occupation',
              required: true,
              options: [
              ],
              },
              expressions: {
              'props.disabled': '!model.CustomerName',
              },
            },
            {
              className: 'col-4',
              type: 'input',
              key: 'SalaryPerAnnum',
              
              props: {
              label: `Salary/Year (${this.commonDetails[0].Currency})`,
              required: true,
              options: [
               
              ],
              },
              validators: {
                validation: [ForceLengthValidators.maxLength(20), ForceLengthValidators.min(1)]
              },
              hooks: {
              onInit: (field: FormlyFieldConfig) => {
                field.formControl.valueChanges.subscribe(() => {
                  this.getSIValue();
                });
              },
              },
              expressions: {
              },
            },
            {
              className: 'col-4',
              type: 'select',
              key: 'JobJoiningMonth',
              props: {
              label: 'Job Joined  Year',
              required: true,
              options: [
                { label: '12 Months', value: '12' },
                { label: '24 Months', value: '24' },
                { label: '36 Months', value: '36' },
              ],
              },
              expressions: {
              'props.disabled': '!model.CustomerName',
              },
            },
            // {
            //   className: 'col-4',
            //   type: 'select',
            //   key: 'BetweenDiscontinued',
            //   props: {
            //   label: 'Between Discontinued?',
            //   required: true,
            //   options: [
            //     { label: '- Select -', value: '' },
            //     { label: 'Yes', value: 'Y' },
            //     { label: 'No', value: 'N' },
            //   ],
            //   },
              
            //   expressions: {
            //   'props.disabled': '!model.CustomerName',
            //   },
            // },
            // {
            //   className: 'col-4',
            //   type: 'select',
            //   key: 'EthicalWorkInvolved',
            //   props: {
            //   label: 'Involved in Unethical Work?',
            //   required: true,
            //   options: [
            //     { label: '- Select -', value: '' },
            //     { label: 'Yes', value: 'Y' },
            //     { label: 'No', value: 'N' },
            //   ],
            //   },
            //   expressions: {
            //   'hide': "model.BetweenDiscontinued!='Y'",
            //   },
            // },
            {
              className: 'col-4',
              type: 'input',
              key: 'SumInsured',
              props: {
              label: `WorkMen's SumInsured  (${this.commonDetails[0].Currency})`,
              required: true,
              options: [
               
              ],
              },
              validators: {
                validation: [ForceLengthValidators.maxLength(20), ForceLengthValidators.min(1)]
              },
              expressions: {
                
              },
            },
            ]
          }
          ],
      }
      
    ];
  }
  this.BenifitList=[
  {Code:1,CodeDescription:'12 Months'},
  {Code:2,CodeDescription:'24 Months'},
  {Code:3,CodeDescription:'36 Months'},
  ]
  this.getUWDetails()
}
getUWDetails(){
  let ReqObj = {
  "Limit":"0",
  "Offset":"100",
  "ProductId": this.productId,
  "LoginId": this.loginId,
  "InsuranceId": this.insuranceId,
  "BranchCode": this.branchCode
  }
  let urlLink = `${this.commonApiUrl}master/getactiveuwquestions`;
  this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
    (data: any) => {
      let res:any = data.Result;
      if(res.length!=0){
        this.uwQuestionList = res;
        this.getEditUwQuestions();
      }
      else{
      }
    },
    (err) => { },
  );
}
getEditUwQuestions(){
  let ReqObj = {
    "InsuranceId": this.insuranceId,
    "ProductId": this.productId,
    "LoginId": this.loginId,
    "RequestReferenceNo": this.requestReferenceNo,   
    "VehicleId": "1"
  }
  let urlLink = `${this.commonApiUrl}api/getuwquestionsdetails`;
  this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
    (data: any) => {
      let uwList = data?.Result;
      if(uwList.length!=0){
        let i=0;
        for(let ques of uwList){
          let entry = this.uwQuestionList.find(ele=>ele.UwQuestionId == ques.UwQuestionId);
          if(entry){ entry.Value = ques.Value};
          i+=1;
          if(i==uwList.length){
            this.uwQuestionList.forEach(x =>  {
              x.Value = x.Value ? '' || 'N' : 'N'
           });
            this.questionSection = true; console.log("Final UW List",this.uwQuestionList); }
        }
      }
      else{
        let i=0
        for(let ques of this.uwQuestionList){
          ques.Value='N';
          i+=1;
          if(i==this.uwQuestionList.length){this.questionSection = true; console.log("Final UW List",this.uwQuestionList); }
        }
      }
    },
    (err) => { },
  );
}
getProductBasedSchema(productId){
  if(productId=='13'){
    this.http.get("assets/json-schema/personalAccident.json").subscribe(data =>{
      console.log("JSONNNNNN",data);
      let res:any = data;
      let  schema = res.schema;
      this.model = res.model;
      this.fields = [this.formlyJsonschema.toFieldConfig(schema)];
      console.log("Fields ",this.fields)
    })
    // this.http
    //   .get<any>(``)
    //   .pipe(
    //     tap(({ schema, model }) => {
    //       this.form = new FormGroup({});
    //       this.fields = [this.formlyJsonschema.toFieldConfig(schema)];
    //       this.model = model;
    //     }),
    //   )
    //   .subscribe();

  }
}
getSIValue(){
  let salary = this.productItem?.SalaryPerAnnum;
  let benefits = this.productItem?.BenefitCoverMonth;
  let sumInsured = this.productItem?.SumInsured;
  if(salary!=null && salary !='' && salary!=undefined){
    if(benefits!=null && benefits!='' && benefits!=undefined){
      if(benefits == '12'){
        this.productItem.SumInsured = String(Number(salary)*1);
        this.form.controls['SumInsured'].setValue(this.productItem.SumInsured)
      }
      else if(benefits == '24'){
        this.productItem.SumInsured = String(Number(salary)*2);
        this.form.controls['SumInsured'].setValue(this.productItem.SumInsured)
      }
      else if(benefits == '36'){
        this.productItem.SumInsured = String(Number(salary)*3);
        this.form.controls['SumInsured'].setValue(this.productItem.SumInsured)
      }
    }
  }
}
onAddVehicle(value){
  //sessionStorage.setItem('vehicleType',value);
  // //this.updateComponent.resetVehicleTab();
    if(value=='edit'){

      this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/excess-discount']);
    }
    if(value=='new'){
      this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/excess-discount']);
    }

}
getYearList(){
  var d = new Date();
  var year = d.getFullYear();
  var month = d.getMonth();
  var day = d.getDate();
  const currentYear = new Date().getFullYear()-40, years = [];
  while ( year >= currentYear ) {
    let yearEntry = year--
    years.push({"label":String(yearEntry),"value":String(yearEntry)});
    if(year==currentYear){
      let defaultObj = [{'label':'-Select-','value':''}]
      this.fields[0].fieldGroup[0].fieldGroup[4].props.options = defaultObj.concat(years);
      let referenceNo =  sessionStorage.getItem('quoteReferenceNo');
      if(referenceNo){
        this.requestReferenceNo = referenceNo;
        this.setFormValues()
      }
      else{
          this.productItem = new ProductData();
      }
    }
    
  }   
}
  onStartDateChange(){

  }
  getOccupationList(){
		let ReqObj = {
		  "InsuranceId": this.insuranceId,
      "BranchCode": this.branchCode,
      "ProductId":  this.productId
		}
		let urlLink = `${this.commonApiUrl}master/dropdown/occupation`;
		this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
		  (data: any) => {
			console.log(data);
			if(data.Result){
        let defaultSelect = [{"label":'- Select -',"value":""}]
			   this.occupationList = defaultSelect.concat(data.Result);
			   for(let i = 0; i < this.occupationList.length; i++){
				this.occupationList[i].label = this.occupationList[i]['CodeDesc'];
				this.occupationList[i].value = this.occupationList[i]['Code'];
					delete this.occupationList[i].CodeDesc;
					if(i==this.occupationList.length-1){
              this.fields[0].fieldGroup[0].fieldGroup[2].props.options = this.occupationList;
              if(this.productId=='15' || this.productId=='14'){
                this.getYearList();
              }
              else{
                let referenceNo =  sessionStorage.getItem('quoteReferenceNo');
                if(referenceNo){
                  this.requestReferenceNo = referenceNo;
                  this.setFormValues()
                }
                else{
                    this.productItem = new ProductData();
                }
              }
              
             
           
						// if(this.customerReferenceNo){
						// 	this.setValues();
						// }
						//this.getBusinessTypeList();
						
					}
				}
			}
		  },
		  (err) => { },
		);
  }
  setFormValues(){
    let urlLink:any;
    let ReqObj = {
      "RequestReferenceNo": this.requestReferenceNo,
      "RiskId":"1"
    }
    urlLink =  `${this.motorApiUrl}api/geteservicebyriskid`;
    this.sharedService.onPostMethodSync(urlLink, ReqObj).subscribe(
      (data: any) => {
        console.log(data);
        if(data.Result){
            let customerData = data.Result;
            this.quoteDetails = data.Result;
            this.productItem = new ProductData();
            this.applicationId = customerData.ApplicationId;
            this.productItem.CustomerName = customerData.CustomerName;
            this.productItem.BetweenDiscontinued = customerData.BetweenDiscontinued;
            this.productItem.EthicalWorkInvolved = customerData.EthicalWorkInvolved;
            this.productItem.JobJoiningMonth = customerData.JobJoiningMonth;
            this.productItem.OccupationType = customerData.OccupationType;
            this.productItem.SalaryPerAnnum = customerData.SalaryPerAnnum;
            this.productItem.SectionId = customerData.SalaryPerAnnum;
            this.productItem.SumInsured = customerData.SumInsured;
            this.productItem.BenefitCoverMonth = customerData.BenefitCoverMonth;
            let dob = "";
            if(customerData.Dob!='' && customerData.Dob!=null && customerData!=undefined){
              var dateParts = customerData?.Dob.split("/");
                this.productItem.Dob = dateParts[2]+'-'+dateParts[1]+'-'+dateParts[0];
            }
            let quoteStatus = sessionStorage.getItem('QuoteStatus');
            if(quoteStatus=='AdminRP' || quoteStatus=='AdminRA' || quoteStatus=='AdminRR'){
                if(this.applicationId!='01' && this.applicationId!='1'){ this.issuerSection = true; }
                else{ this.issuerSection = false; }
            }
            else if(this.userType!='Broker' && this.userType!='User'){ this.issuerSection = true; }
            else this.issuerSection = false
          }
        },
        (err) => { },
      );
  }
  onFormSubmit(){
    let createdBy="";
    let quoteStatus = sessionStorage.getItem('QuoteStatus');
    let appId = "1",loginId="",brokerbranchCode="";
    if(quoteStatus=='AdminRP' || quoteStatus=='AdminRA' || quoteStatus=='AdminRR'){
        //createdBy = this.vehicleDetailsList[0].CreatedBy;
    }
    else{
      createdBy = this.loginId;
      if(this.userType!='Issuer'){
        this.brokerCode = this.agencyCode;
        appId = "1"; loginId=this.loginId;
        brokerbranchCode = this.brokerbranchCode;
      }
      else{
        appId = this.loginId;
        loginId = this.commonDetails[0].LoginId
        brokerbranchCode = null;
      }
    }
    this.applicationId = appId;
    if(quoteStatus=='AdminRP' || quoteStatus=='AdminRA' || quoteStatus=='AdminRR'){
        if(this.applicationId!='01' && this.applicationId!='1'){ this.issuerSection = true; }
        else{ this.issuerSection = false; }
    }
    else if(this.userType!='Broker' && this.userType!='User'){ this.issuerSection = true; }
    else this.issuerSection = false
    this.subuserType = sessionStorage.getItem('typeValue');
    console.log("AcExecutive",this.acExecutiveId);
    //if(vehicleDetails?.FleetOwnerYn==null) vehicleDetails.FleetOwnerYn = 'N';
   
   
    console.log("Quote Status Received",quoteStatus,this.commonDetails)
    if(quoteStatus=='AdminRP' || quoteStatus=='AdminRA' || quoteStatus=='AdminRR'){
      //brokerbranchCode = this.vehicleDetailsList[0].BrokerBranchCode;
    }
    let dob="";
    if(this.productItem.Dob!='' && this.productItem.Dob!=null && this.productItem.Dob!=undefined){
      dob = this.datePipe.transform(this.productItem.Dob, "dd/MM/yyyy");
    }
    if(this.commonDetails[0].CommissionType!=null) this.commissionType = this.commonDetails[0].CommissionType;
    if(this.commonDetails[0].AcexecutiveId!=null) this.acExecutiveId = this.commonDetails[0].AcexecutiveId;
    if(this.issuerSection){
      this.sourceType = this.commonDetails[0].SourceType;
      this.bdmCode = this.commonDetails[0].BrokerCode;
      this.brokerCode = this.commonDetails[0].BrokerCode;
      this.brokerbranchCode =  this.commonDetails[0].BrokerBranchCode;
      
    }
    if(this.commonDetails[0].CustomerCode!=null && this.commonDetails[0].CustomerCode!=undefined) this.customerCode = this.commonDetails[0].CustomerCode;
    let sectionId=null;
    if(this.productId=='13') sectionId = '35';
    else if(this.productId=='14') sectionId = '37';
    else if(this.productId=='15') sectionId = '38';
    if(this.productItem.BetweenDiscontinued=='N') this.productItem.EthicalWorkInvolved='N';
    let ReqObj = {
      "AcexecutiveId": this.acExecutiveId,
      "AgencyCode": this.agencyCode,
      "BenefitCoverMonth": this.productItem.BenefitCoverMonth,
      "CreatedBy": createdBy,
      "Havepromocode": this.commonDetails[0].HavePromoCode,
      "OccupationType": this.productItem.OccupationType,
      "PolicyEndDate": this.commonDetails[0].PolicyEndDate,
      "PolicyStartDate": this.commonDetails[0].PolicyStartDate,
      "Promocode": this.commonDetails[0].Promocode,
      "RiskId": this.commonDetails[0].RiskId,
      "SalaryPerAnnum": this.productItem.SalaryPerAnnum,
      "SourceType": this.sourceType,
      "SubUsertype": this.subuserType,
      "SumInsured": this.productItem.SumInsured,
      "CommissionType": this.commissionType,
        "BrokerCode": this.brokerCode,
        "LoginId": loginId,
        "ApplicationId": appId,
        "CustomerReferenceNo": this.customerDetails?.CustomerReferenceNo,
        "RequestReferenceNo": this.requestReferenceNo,
        "BranchCode": this.branchCode,
        "ProductId": this.productId,
        "UserType": this.userType,
        "BrokerBranchCode": this.brokerbranchCode,
        "BdmCode": this.bdmCode,
        "CustomerCode": this.customerCode,
        "InsuranceId": this.insuranceId,
        "SectionId": sectionId,
         "Currency": this.commonDetails[0].Currency,
        "ExchangeRate": this.commonDetails[0].ExchangeRate,
       "HavePromoCode": this.commonDetails[0].HavePromoCode,
        "PromoCode": this.commonDetails[0].PromoCode,
        "PolicyPeriod": this.commonDetails[0].PolicyPeriod,
        "CustomerName": this.productItem.CustomerName,
        "Dob":dob,
        "JobJoiningMonth":this.productItem.JobJoiningMonth,
        "BetweenDiscontinued": this.productItem.BetweenDiscontinued,
        "EthicalWorkInvolved":this.productItem.EthicalWorkInvolved
    } 
    let urlLink = `${this.motorApiUrl}api/saveeservicedetails`; 
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
		  (data: any) => {
			console.log(data);
			  if(data.Result){
          this.requestReferenceNo = data?.Result[0]?.RequestReferenceNo;
          sessionStorage.setItem('quoteReferenceNo',data?.Result[0]?.RequestReferenceNo);
         let entry = data?.Result;
         entry['PolicyEndDate'] = this.commonDetails[0].PolicyEndDate;
         entry['PolicyStartDate'] = this.commonDetails[0].PolicyStartDate;

         entry['InsuranceType'] =  sectionId;
         entry['MSRefNo'] = data?.Result[0]?.MSRefNo;
         entry['VdRefNo'] = data?.Result[0]?.VdRefNo;
         entry['CdRefNo'] = data?.Result[0]?.CdRefNo;
         entry['RequestReferenceNo'] = data?.Result[0]?.RequestReferenceNo;
         entry['Active'] = true;
         entry['VehicleId'] = data.Result[0]?.RiskId;
         if(this.uwQuestionList.length!=0){
          let i = 0;
          let uwList:any[]=[];
          for(let ques of this.uwQuestionList){
            ques['BranchCode'] = this.branchCode;
              let quoteStatus = sessionStorage.getItem('QuoteStatus');
              // if(quoteStatus=='AdminRP'){
              //     createdBy = ;
              // }
              // else{
              //   createdBy = this.loginId;
              // }
            if(ques.QuestionType == '01'){
              
              ques['CreatedBy'] = createdBy;
              ques['RequestReferenceNo'] = this.requestReferenceNo;
              ques['UpdatedBy'] = this.loginId;
              ques["VehicleId"] ="1"
              uwList.push(ques);
            } 
            else if(ques.Value!=""){
              ques['CreatedBy'] = createdBy;
              ques['RequestReferenceNo'] = this.requestReferenceNo;
              ques['UpdatedBy'] = this.loginId;
              ques["VehicleId"] ="1"
              uwList.push(ques);
            } 
            i+=1;
            if(i==this.uwQuestionList.length) this.onSaveUWQues(uwList,entry);
          }
        }
        else{
         this.getCalculationDetails(entry); 
        }
        }
      },
		  (err) => { },
		);
  }
  getCalculationDetails(vehicleDetails){
    let createdBy="";
          let quoteStatus = sessionStorage.getItem('QuoteStatus');
          if(quoteStatus=='AdminRP'){
              //createdBy = this.vehicleDetailsList[0].CreatedBy;
          }
          else{
            createdBy = this.loginId;
          }
    let sectionId=null;
    if(this.productId=='13') sectionId = '35';
    else if(this.productId=='14') sectionId = '37';
    else if(this.productId=='15') sectionId = '38';
    let ReqObj = {
        "InsuranceId": this.insuranceId,
        "BranchCode": this.branchCode,
        "AgencyCode": this.agencyCode,
        "SectionId": sectionId,
        "ProductId": this.productId,
        "MSRefNo": vehicleDetails?.MSRefNo,
        "VehicleId": vehicleDetails?.VehicleId,
        "CdRefNo": vehicleDetails?.CdRefNo,
        "VdRefNo": vehicleDetails?.VdRefNo,
        "CreatedBy": createdBy,
        "productId": this.productId,
        "sectionId": sectionId,
        "RequestReferenceNo": this.requestReferenceNo
    }
    let urlLink = `${this.commonApiUrl}calculator/calc`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        let res:any = data;
        
        this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/excess-discount']);
        
      },
      (err) => { },
    );
  }
  onSaveUWQues(uwList,entry){
    if(uwList.length!=0){ 
      let urlLink = `${this.commonApiUrl}api/saveuwquestions`;
      this.sharedService.onPostMethodSync(urlLink, uwList).subscribe(
        (data: any) => {
          if(data.Result){
            this.getCalculationDetails(entry); 
          }
        },
        (err) => { },
      );
    }
  }
}
