import { Component, OnInit } from '@angular/core';
import * as Mydatas from '../../../../../app-config.json';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import * as moment from 'moment';
import { threadId } from 'worker_threads';
import { UpdateCustomerDetailsComponent } from '../../update-customer-details.component';
import { elementAt } from 'rxjs/operators';
import { SharedService } from '../../../../../shared/shared.service';
declare var $:any;

@Component({
  selector: 'app-vehicle-details',
  templateUrl: './vehicle-details.component.html',
  styleUrls: ['./vehicle-details.component.css']
})
export class VehicleDetailsComponent implements OnInit {

  drivenBy:any="D";gpsYn:any="N";windYN:any="Y";
  productList:any[]=[];productValue:any="";motorYN:any="Y";
  claimsYN:any="N";playerType:any="R";collateralYN:any="N";
  borrowerList:any[]=[];borrowerValue:any;fleetYN:any="N";
  collateralValue:boolean = false;fleetValue:boolean=false;
  public AppConfig: any = (Mydatas as any).default;
  public ApiUrl1: any = this.AppConfig.ApiUrl1;
  public CommonApiUrl: any = this.AppConfig.CommonApiUrl;
  public motorApiUrl:any = this.AppConfig.MotorApiUrl;
  typeList: any[]=[];cityList:any[]=[];addSection:boolean = false;
  classList: any[]=[];cityValue:any;currencyValue:any;
  typeValue:any;classValue:any;bodyTypeValue:any;policyEndDate:any;
  exchangeRate:any="0";vehicleSI:any;accessoriesSI:any;
  windShieldSI:any;tppdSI:any;policyStartDate:any;minDate:Date;
  motorTypeList: any[]=[];currencyList:any[]=[];noOfDays:any;
  customerDetails: any;havePromoCodeYN:any;
  vehicleDetails: any;vehicleId: any;userDetails: any;
  loginId: any;agencyCode:any;branchCode:any;productId:any;
  insuranceId: any;requestReferenceNo:any=null;
  motorUsageValue: any;promoCode:any;
  motorUsageList: any[]=[];
  endMinDate: Date;
  title: any;clientName: any;dateOfBirth: any;
  emailId: any;mobileNo: any;idNumber: any;
  collateralName: any="";questionSection:boolean=false;
  firstLossPayee: any="";
  noOfVehicles: any="";noOfCompPolicy:any="";
  claimRatio: any="";customerHeader2:any[]=[];
  bankList: any[]=[];motorDetails:any;commissionType:any;
  clientType: string;customerData2:any[]=[];searchBy:any;
  branchList: any[]=[];executiveList:any[]=[];uwQuestionList:any[]=[];
  userType: any;acExecutiveId:any="";searchValue:any;brokerbranchCode:any;
  brokerCode: any="";brokerLoginId: any="";subuserType: any="";applicationId: any="";
  currentIndex: number;totalCount: any;vehicleDetailsList: any[]=[];
  finalSection: boolean;customerHeader:any[]=[];searchList:any[]=[];
  selectedVehicle: any;adminSection:boolean = false;issuerSection:boolean = false;
  customerCode: any;
  bdmCode: any;
  sourceType: any;
  constructor(private router:Router,private sharedService: SharedService,
    private updateComponent:UpdateCustomerDetailsComponent,
   private datePipe:DatePipe) {
    this.minDate = new Date();
    this.customerDetails = JSON.parse(sessionStorage.getItem('customerDetails'));

    this.vehicleDetails = JSON.parse(sessionStorage.getItem('vehicleDetails'));
    let quoteRefNo = sessionStorage.getItem('quoteReferenceNo');
    if(quoteRefNo) this.requestReferenceNo = quoteRefNo;
    this.userDetails = JSON.parse(sessionStorage.getItem('Userdetails'));
    console.log("User Details",this.userDetails)
    this.loginId = this.userDetails.Result.LoginId;
    this.userType = this.userDetails?.Result?.UserType;
    this.agencyCode = this.userDetails.Result.OaCode;
    this.brokerbranchCode = this.userDetails.Result.BrokerBranchCode;
    this.branchCode = this.userDetails.Result.BranchCode;
    this.branchList = this.userDetails.Result.LoginBranchDetails;
    this.productId = this.userDetails.Result.ProductId;
    this.insuranceId = this.userDetails.Result.InsuranceId;
    if(this.userType!='Broker'){
      let quoteStatus = sessionStorage.getItem('QuoteStatus');
      if(quoteStatus=='AdminRP'){
        this.adminSection = true;this.issuerSection = false;
      }
    }
    this.getInsuranceTypeList();
   }

  ngOnInit(): void {
    this.searchList = [
      { "Code":"","CodeDesc":"---Select---"},
      { "Code":"02","CodeDesc":"Register Number"},
      { "Code":"01","CodeDesc":"Chassis Number"},

    ];
    this.customerHeader =  [
      { key: 'Chassisnumber', display: 'Chassis Number' },
      { key: 'Registrationnumber', display: 'Registration No' },
      { key: 'PolicyTypeDesc', display: 'Policy Type' },
     { key: 'Vehiclemake', display: 'Make' },
      { key: 'Vehcilemodel', display: 'Model' },
      { key: 'OverallPremiumFc', display: 'Premium' },
      {
        key: 'actions',
        display: 'Action',
        config: {
          isRemove: true,
        },
      }
    ];
    this.customerHeader2 =  [
      {
        key: 'actions',
        display: 'Select',
        config: {
          select: true,
        },
      },
      { key: 'ReqChassisNumber', display: 'Chassis Number' },
      { key: 'Registrationnumber', display: 'Registration No' },
      { key: 'Vehiclemake', display: 'Make' },
      { key: 'Vehcilemodel', display: 'Model' },
      { key: 'Status', display: 'Status' },


    ];
  }
  onChangeEndDate(){
    const oneday = 24 * 60 * 60 * 1000;
    const momentDate = new Date(this.policyEndDate); // Replace event.value with your date value
    const formattedDate = moment(momentDate).format("YYYY-MM-DD");
    const formattedDatecurrent = new Date(this.policyStartDate);
    console.log(formattedDate);

  console.log(formattedDatecurrent);

  this.noOfDays = Math.round(Math.abs((Number(momentDate)  - Number(formattedDatecurrent) )/oneday)+1);
  }
  getInsuranceTypeList(){
    let ReqObj = {
      "ProductId": this.productId,
      "InsuranceId": this.insuranceId,
      "BranchCode": this.branchCode
    }
    let urlLink = `${this.ApiUrl1}master/dropdown/productsection`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        console.log(data);
        if(data.Result){
            this.typeList = data.Result;
            this.getInsuranceClassList();
        }

      },
      (err) => { },
    );
  }
  getInsuranceClassList(){
    let ReqObj = {
      "InsuranceId": this.insuranceId,
      "ProductId": this.productId,
      "BranchCode": this.branchCode
    }
    let urlLink = `${this.ApiUrl1}master/dropdown/policytype`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        if(data.Result){
            this.classList = data.Result;
            this.getBorrowerList();
        }
      },
      (err) => { },
    );
  }
  getBorrowerList(){
    let ReqObj = {
      "InsuranceId": this.insuranceId,
      "BranchCode": this.branchCode
    }
    let urlLink = `${this.CommonApiUrl}dropdown/borrowertype`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        console.log(data);
        if(data.Result){
            this.borrowerList = data.Result;
            this.getBankList();
        }

      },
      (err) => { },
    );
  }
  getBankList(){
    let ReqObj = {
      "InsuranceId": this.insuranceId,
      "BranchCode": this.branchCode
    }
    let urlLink = `${this.CommonApiUrl}master/dropdown/bankmaster`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        console.log(data);
        if(data.Result){
            this.bankList = data.Result;
           this.getUWDetails();
        }

      },
      (err) => { },
    );
  }
  onChangeBodyType(){
    if(this.bodyTypeValue=='7') this.cityValue='';
  }
  getMotorTypeList(type,motorValue,vehicleUsage){
    let ReqObj = {
      "SectionId": this.typeValue,
      "InsuranceId": this.insuranceId,
      "BranchCode": this.branchCode
    }
    let urlLink = `${this.CommonApiUrl}master/dropdown/bodytype`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        console.log(data);
        if(data.Result){
          if(type=='change') this.cityValue = null;
            this.motorTypeList = data.Result;
            this.bodyTypeValue = motorValue;
            // if(this.motorDetails){
            //   let value = this.motorTypeList.find(ele=>ele.CodeDesc == this.motorDetails?.VehicleType);
            //   if(value){ this.bodyTypeValue = value.Code}
            // }

            this.getMotorUsageList(vehicleUsage);
        }

      },
      (err) => { },
    );
  }
  getCurrencyList(){
    let ReqObj = {
      "InsuranceId":this.insuranceId,
      "BranchCode": this.branchCode
    }
    let urlLink = `${this.CommonApiUrl}master/dropdown/currency`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        console.log(data);
        if(data.Result){
            this.currencyList = data.Result;
            this.getCityLimitList();
        }

      },
      (err) => { },
    );
  }
  getMotorUsageList(vehicleValue){
    let ReqObj = {
      "InsuranceId": this.insuranceId,
      "SectionId": this.typeValue,
      "BranchCode": this.branchCode
    }
    let urlLink = `${this.CommonApiUrl}api/dropdown/vehicleusage`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        console.log(data);
        if(data.Result){
            this.motorUsageList = data.Result;
            this.motorUsageValue = vehicleValue;
            // if(this.motorDetails){
            //   let value = this.motorTypeList.find(ele=>ele.CodeDesc == this.motorDetails?.Motorusage);
            //   if(value){ this.motorUsageValue = value.Code}
            // }

            //this.getMotorUsageList();
        }

      },
      (err) => { },
    );
  }
  getCityLimitList(){
    let ReqObj = {
      "InsuranceId": this.insuranceId,
      "BranchCode": this.branchCode
    }
    let urlLink = `${this.CommonApiUrl}dropdown/citylimit`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        console.log(data);
        if(data.Result){
            this.cityList = data.Result;
            if(this.customerDetails){
              this.title = this.customerDetails?.TitleDesc;
              this.clientName = this.customerDetails?.ClientName;
              this.dateOfBirth = this.customerDetails?.DobOrRegDate;
              if(this.customerDetails?.PolicyHolderType == '1') this.clientType = "Individual";
              if(this.customerDetails?.PolicyHolderType == '2') this.clientType = "Corporate";
              this.emailId = this.customerDetails?.Email1;
              this.mobileNo = this.customerDetails?.MobileNo1;
              this.idNumber = this.customerDetails?.IdNumber;
            }
            let vehicleDetails = JSON.parse(sessionStorage.getItem('vehicleDetailsList'));
            if(vehicleDetails){
              if(vehicleDetails.length!=0){
                let i=0;
                for(let vehicle of vehicleDetails){
                  if(vehicle.Active){
                      if(vehicle.RiskDetails){
                          vehicle['Chassisnumber'] = vehicle.RiskDetails.Chassisnumber;
                          vehicle['Registrationnumber'] = vehicle.RiskDetails.Registrationnumber;
                          vehicle['Vehiclemake'] = vehicle.RiskDetails.Vehiclemake;
                          vehicle['Vehcilemodel'] = vehicle.RiskDetails.Vehcilemodel;
                      }
                  }
                  i+=1;
                  if(i==vehicleDetails.length){
                    this.currencyValue = vehicleDetails[0].Currency;
                    this.exchangeRate = vehicleDetails[0].ExchangeRate;
                    this.vehicleDetailsList = vehicleDetails;
                    this.acExecutiveId = vehicleDetails[0].AcExecutiveId;
                    this.commissionType = vehicleDetails[0].CommissionType;
                    
                    this.havePromoCodeYN = vehicleDetails[0].HavePromoCode;
                    if(this.policyStartDate==null || this.policyStartDate == '' || this.policyStartDate == undefined){
                      console.log("Vehicle Details on First Edit",this.policyStartDate,vehicleDetails[0])
                      if(vehicleDetails[0].PolicyStartDate != null ){
                        var dateParts = vehicleDetails[0].PolicyStartDate.split("/");
                        // month is 0-based, that's why we need dataParts[1] - 1
                        this.policyStartDate = dateParts[2]+'-'+dateParts[1]+'-'+dateParts[0];
                        console.log("Policy Start",this.policyStartDate)
                        //this.policyStartDate = dateObject.toString()
                      }
                      if(vehicleDetails[0].PolicyEndDate != null ){
                        var dateParts = vehicleDetails[0].PolicyEndDate.split("/");
                        // month is 0-based, that's why we need dataParts[1] - 1
                        this.policyEndDate = dateParts[2]+'-'+dateParts[1]+'-'+dateParts[0];
                        this.onChangeEndDate();
                      }
                    }
                    this.promoCode = vehicleDetails[0].PromoCode;
                    let vehicleId = sessionStorage.getItem('editVehicleId');
                    console.log("Vehicle Id on Edit",this.vehicleDetailsList);
                    //this.updateComponent.vehicleDetails = vehicleDetails;
                    if(vehicleId){
                      let index = this.vehicleDetailsList.findIndex(ele=>ele.Vehicleid==vehicleId);
                      if(vehicleDetails[index]?.Active==true){
                        this.vehicleId = String(vehicleDetails[index].Vehicleid);
                        this.getEditVehicleDetails(this.vehicleId,'direct');
                        this.currentIndex = index+1;
                        this.totalCount = vehicleDetails.length;
                      }
                      else{
                        this.vehicleDetails = vehicleDetails[index];
                        this.motorDetails = vehicleDetails[index];
                        this.currentIndex = index+1;
                        this.totalCount = vehicleDetails.length;
                        console.log("Motor Details",this.motorDetails);
                        this.setVehicleValues('direct');
                        //this.currencyValue = this.motorDetails.Currency;
                        this.onCurrencyChange();
                      }
                    }
                    else{
                      if(vehicleDetails[0]?.Active==true){
                        this.vehicleId = String(vehicleDetails[0].Vehicleid);
                        this.getEditVehicleDetails(this.vehicleId,'direct');
                        this.currentIndex = 1;
                        this.totalCount = vehicleDetails.length;
                      }
                      else{
                        this.vehicleDetails = vehicleDetails[0];
                        this.motorDetails = vehicleDetails[0];
                        this.currentIndex = 1;
                        this.totalCount = vehicleDetails.length;
                        console.log("Motor Details",this.motorDetails);
                        this.setVehicleValues('direct');
                        //this.currencyValue = this.motorDetails.Currency;
                        this.onCurrencyChange();
                      }
                    }
                  }
                }
                
  
  
              }
              else{
                let vehicleId = sessionStorage.getItem('editVehicleId');
                if(vehicleId){
                  this.getEditVehicleDetails(vehicleId,'direct');
                }
                else{
                  this.addSection = true;
                }
              }
            }
            else{
              this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/customer-details']);
            }
            
        }

      },
      (err) => { },
    );
  }
  onChangeClassType(){
    this.vehicleSI ="0";this.accessoriesSI="0",this.windShieldSI="0";this.tppdSI = "0";
  }
  getEditVehicleDetails(vehicleId,type){
    let ReqObj =  {
      "RequestReferenceNo": this.requestReferenceNo,
       "Idnumber": this.customerDetails?.IdNumber,
      "Vehicleid": vehicleId
     }
     let urlLink = `${this.motorApiUrl}api/getmotordetails`;
    this.sharedService.onPostMethodSync(urlLink, ReqObj).subscribe(
      (data: any) => {
        if(data.Result){
          this.vehicleDetails = data.Result;
          //this.updateComponent.vehicleDetails = this.vehicleDetails;
          if(type!='save'){
            this.setVehicleValues('edit');
          }
          else{
            this.onFormSubmit('save');
          }
        }
      },
      (err) => { },
    );
  }
  setVehicleValues(type){
    console.log("Vehicle Details",this.vehicleDetails);
    this.vehicleId = String(this.vehicleDetails?.Vehicleid);
    console.log("Vehicle Id Setted",this.vehicleId);
    this.typeValue = this.vehicleDetails?.Insurancetype;
    this.classValue = this.vehicleDetails?.InsuranceClass;
    if(type=='edit'){
      this.getMotorTypeList('direct',this.vehicleDetails?.VehicleType,this.vehicleDetails?.Motorusage)
      this.bodyTypeValue = this.vehicleDetails?.VehicleType;
      this.motorUsageValue = this.vehicleDetails?.Motorusage;
      this.collateralYN = this.vehicleDetails?.CollateralYn;
      if(this.collateralYN=='Y'){
        this.collateralValue = true;
        this.collateralName = this.vehicleDetails?.CollateralName;
        this.firstLossPayee = this.vehicleDetails?.FirstLossPayee;
        this.borrowerValue = this.vehicleDetails?.BorrowerType;
      }
      if(this.vehicleDetails?.FleetOwnerYn){
        if(this.fleetYN!='')
        this.fleetYN = this.vehicleDetails?.FleetOwnerYn;
        if(this.fleetYN=='Y'){
          this.fleetValue = true;
          this.noOfVehicles = this.vehicleDetails?.NoOfVehicles;
          this.noOfCompPolicy = this.vehicleDetails?.NoOfComprehensives;
          this.claimRatio = this.vehicleDetails?.ClaimRatio
        }
      }
    }
    else{

    }
    this.cityValue = this.vehicleDetails?.CityLimit;
    if(this.policyStartDate==null || this.policyStartDate == '' || this.policyStartDate == undefined){
      console.log("Vehicle Details on Edit",this.policyStartDate,this.vehicleDetails)
      if(this.vehicleDetails?.PolicyStartDate != null ){
        var dateParts = this.vehicleDetails?.PolicyStartDate.split("/");
  
        // month is 0-based, that's why we need dataParts[1] - 1
        this.policyStartDate = dateParts[2]+'-'+dateParts[1]+'-'+dateParts[0];
        console.log("Policy Start",this.policyStartDate)
        //this.policyStartDate = dateObject.toString()
      }
      if(this.vehicleDetails?.PolicyEndDate != null ){
        var dateParts = this.vehicleDetails?.PolicyEndDate.split("/");
  
  // month is 0-based, that's why we need dataParts[1] - 1
        this.policyEndDate = dateParts[2]+'-'+dateParts[1]+'-'+dateParts[0];
        this.onChangeEndDate();
      }
    }
   
    if(type=='edit'){
      this.claimsYN = this.vehicleDetails?.NcdYn;
      this.gpsYn = this.vehicleDetails?.Gpstrackinginstalled;
      this.vehicleSI = String(this.vehicleDetails?.SumInsured);
      this.CommaFormatted();
      this.windShieldSI = String(this.vehicleDetails?.WindScreenSumInsured);
      this.WindSICommaFormatted();
      this.tppdSI = String(this.vehicleDetails?.TppdIncreaeLimit);
      this.TppdCommaFormatted();
      this.accessoriesSI = String(this.vehicleDetails?.AcccessoriesSumInsured);
      this.accessoriesCommaFormatted();
      this.getVehicleDetails(this.vehicleDetails?.Chassisnumber);
    }


  }
  onSearchVehicle(){
    this.customerData2 = [];
    if(this.searchBy!='' && this.searchBy!=null){
      let chassisNo = "",regNo = "";
      if(this.searchBy=='01'){
        chassisNo = this.searchValue
      }
      else{
        regNo = this.searchValue;
      }
      let ReqObj = {
        "ReqChassisNumber": chassisNo,
        "ReqRegNumber": regNo
      }
      let urlLink = `${this.motorApiUrl}regulatory/showvehicleinfo`;
    this.sharedService.onPostMethodSync(urlLink, ReqObj).subscribe(
      (data: any) => {
        console.log(data);
        if(data.Result){
            this.customerData2 = [data?.Result];
        }
        else if(data.ErrorMessage){
          if(data.ErrorMessage){
            // for(let entry of data.ErrorMessage){
            //   let type: NbComponentStatus = 'danger';
            //   const config = {
            //     status: type,
            //     destroyByClick: true,
            //     duration: 4000,
            //     hasIcon: true,
            //     position: NbGlobalPhysicalPosition.TOP_RIGHT,
            //     preventDuplicates: false,
            //   };
            //   this.toastrService.show(
            //     entry.Field,
            //     entry.Message,
            //     config);
            // }
            console.log("Error Iterate",data.ErrorMessage)
            //this.loginService.errorService(data.ErrorMessage);
          }
      }
      },
      (err) => { },
    );
    }
  }
  getVehicleDetails(chassisNo){
    let ReqObj = {
      "ReqChassisNumber": chassisNo,
      "ReqRegNumber": null
    }
    let urlLink = `${this.motorApiUrl}regulatory/showvehicleinfo`;
  this.sharedService.onPostMethodSync(urlLink, ReqObj).subscribe(
    (data: any) => {
      console.log(data);
      if(data.Result){
      this.updateComponent.vehicleDetails = data.Result;
      this.motorDetails = data.Result;
      console.log("Motor Details",this.motorDetails);
      }
      },
      (err) => { },
    );
  }
  onCurrencyChange(){
    if(this.currencyValue!=null && this.currencyValue!=''){
      let currencyData = this.currencyList.find(ele=>ele.Code==this.currencyValue);
      this.exchangeRate = currencyData?.ExchangeRate;
    }
  }
  onNextVehicle(){

  }
  onPreviousVehicle(){
    this.finalSection = false;
    this.currentIndex = this.currentIndex-1;
    if(this.vehicleDetailsList[this.currentIndex-1]?.Active==true){
      this.vehicleId = String(this.vehicleDetailsList[this.currentIndex-1].Vehicleid);
      this.getEditVehicleDetails(this.vehicleId,'direct');
    }
    else{

      this.vehicleDetails = this.vehicleDetailsList[this.currentIndex-1];
      this.motorDetails = this.vehicleDetailsList[this.currentIndex-1];
      this.totalCount = this.vehicleDetailsList.length;
      console.log("Motor Details",this.motorDetails);
      this.setVehicleValues('direct');
    }
    //this.currencyValue = this.motorDetails.Currency;
    //this.onCurrencyChange();
    $('#slider_0').removeClass('active w3-animate-left');
    $('#slider_0').removeClass('active w3-animate-right');
    $('#slider_0').addClass('active w3-animate-left');
  }
  onFormSubmit(type){
    let createdBy="";
    
    // let quoteStatus = sessionStorage.getItem('QuoteStatus');
    // if(quoteStatus=='AdminRP'){
    //     createdBy = this.vehicleDetailsList[0].CreatedBy;
    // }
    // else{
    //   createdBy = this.loginId;
    // }
    let startDate = "",endDate = "",vehicleSI="",accSI="",windSI="",tppSI="";
    if(this.vehicleSI==undefined) vehicleSI = null;
    else if(this.vehicleSI.includes(',')){ vehicleSI = this.vehicleSI.replace(/,/g, '') }
    else vehicleSI = this.vehicleSI;
    if(this.accessoriesSI==undefined) accSI = null;
    else if(this.accessoriesSI.includes(',')){ accSI = this.accessoriesSI.replace(/,/g, '') }
    else accSI = this.accessoriesSI
    if(this.windShieldSI==undefined) windSI = null;
    else if(this.windShieldSI.includes(',')){ windSI = this.windShieldSI.replace(/,/g, '') }
    else windSI = this.windShieldSI
    if(this.tppdSI==undefined) tppSI = null;
    else if(this.tppdSI.includes(',')){ tppSI = this.tppdSI.replace(/,/g, '') }
    else tppSI = this.tppdSI
    if(this.policyStartDate){
      startDate = this.datePipe.transform(this.policyStartDate, "dd/MM/yyyy");
    }
    if(this.policyEndDate){
      endDate = this.datePipe.transform(this.policyEndDate, "dd/MM/yyyy");
    }
    let quoteStatus = sessionStorage.getItem('QuoteStatus');
    // if(quoteStatus=='AdminRP' || quoteStatus=='AdminRA' || quoteStatus=='AdminRR'){
    //     createdBy = this.vehicleDetailsList[0].CreatedBy;
    // }
    // else{
    //   createdBy = this.loginId;
    // }
    // if(this.userType=='Broker'){
    //   this.brokerCode = this.agencyCode;
    //   createdBy = this.loginId;
      
    //   this.applicationId = "01";
    // }
    this.subuserType = sessionStorage.getItem('typeValue');
    console.log("AcExecutive",this.acExecutiveId);
    
    let appId = "1",loginId="",brokerbranchCode="";
    if(quoteStatus=='AdminRP' || quoteStatus=='AdminRA' || quoteStatus=='AdminRR'){
      brokerbranchCode = this.vehicleDetailsList[0].BrokerBranchCode;
        createdBy = this.vehicleDetailsList[0].CreatedBy;
    }
    else{
      createdBy = this.loginId;
      if(this.userType!='Issuer'){
        this.brokerCode = this.agencyCode;
        appId = "1"; loginId=this.loginId;
        brokerbranchCode = this.brokerbranchCode;
      }
      else{
        appId = this.loginId;
        loginId = this.vehicleDetailsList[0].LoginId;
        loginId = this.updateComponent.brokerLoginId
        brokerbranchCode = null;
      }
    }
    if(this.userType!='Broker' && this.userType!='User'){
      this.sourceType = this.vehicleDetailsList[0].SourceType;
      this.bdmCode = this.vehicleDetailsList[0].BrokerCode;
      this.brokerCode = this.vehicleDetailsList[0].BrokerCode;
      this.brokerbranchCode =  this.vehicleDetailsList[0].BrokerBranchCode;
      this.customerCode = this.vehicleDetailsList[0].CustomerCode;
    }

  console.log("AcExecutive",this.acExecutiveId,this.vehicleDetails);
  let ReqObj = {
    "BrokerBranchCode": brokerbranchCode,
    "AcExecutiveId": this.acExecutiveId,
    "CommissionType": this.commissionType,
    "CustomerCode": this.customerCode,
    "BdmCode": this.bdmCode,
    "BrokerCode": this.brokerCode,
    "LoginId": loginId,
    "SubUserType": this.subuserType,
    "ApplicationId": appId,
    "CustomerReferenceNo": this.customerDetails?.CustomerReferenceNo,
    "RequestReferenceNo": this.requestReferenceNo,
    "Idnumber": this.customerDetails?.IdNumber,
    "VehicleId": this.vehicleId ,
    "AcccessoriesSumInsured": accSI,
    "AccessoriesInformation": "",
    "AdditionalCircumstances": "",
    "AxelDistance": this.vehicleDetails?.AxelDistance,
    "Chassisnumber": this.vehicleDetails?.Chassisnumber,
    "Color": this.vehicleDetails?.Color,
    "CityLimit": this.cityValue,
    "CoverNoteNo": null,
    "OwnerCategory": this.vehicleDetails?.OwnerCategory,
    "CubicCapacity": this.vehicleDetails?.Grossweight,
    "CreatedBy": createdBy,
    "DrivenByDesc": this.drivenBy,
    "EngineNumber": this.vehicleDetails?.EngineNumber,
    "FuelType": this.vehicleDetails?.FuelType,
    "Gpstrackinginstalled": this.gpsYn,
    "Grossweight": this.vehicleDetails?.Grossweight,
    "HoldInsurancePolicy": "N",
    "Insurancetype": this.typeValue,
    "InsuranceId": this.insuranceId,
    "InsuranceClass": this.classValue,
    "InsurerSettlement": "",
    "InterestedCompanyDetails": "",
    "ManufactureYear": this.vehicleDetails?.ManufactureYear,
    "ModelNumber": null,
    "MotorCategory": this.vehicleDetails?.MotorCategory,
    "Motorusage": this.motorUsageValue,
    "NcdYn": this.claimsYN,
    "NoOfClaims": null,
    "NumberOfAxels": this.vehicleDetails?.NumberOfAxels,
    "BranchCode": this.branchCode,
    "AgencyCode": this.agencyCode,
    "ProductId": this.productId,
    "SectionId": this.typeValue,
    "PolicyType": this.customerDetails?.PolicyHolderType,
    "RadioOrCasseteplayer": null,
    "RegistrationYear": this.customerDetails?.DobOrRegDate,
    "Registrationnumber": this.vehicleDetails?.Registrationnumber,
    "RoofRack": null,
    "SeatingCapacity": this.vehicleDetails?.SeatingCapacity,
    "SourceType":this.sourceType,
    "SpotFogLamp": null,
    "Stickerno": null,
    "SumInsured": vehicleSI,
    "Tareweight": this.vehicleDetails?.Tareweight,
    "TppdFreeLimit": null,
    "TppdIncreaeLimit": tppSI,
    "TrailerDetails": null,
    "Vehcilemodel": this.vehicleDetails?.Vehcilemodel,
    "VehicleType": this.bodyTypeValue,
    "Vehiclemake": this.vehicleDetails?.Vehiclemake,
    "WindScreenSumInsured": windSI,
    "Windscreencoverrequired": null,
    "accident": null,
    "periodOfInsurance": this.noOfDays,
    "PolicyStartDate": startDate,
    "PolicyEndDate": endDate,
    "Currency" : this.currencyValue,
    "ExchangeRate": this.exchangeRate,
    "HavePromoCode": this.havePromoCodeYN,
    "PromoCode" : this.promoCode,
    "CollateralYn": this.collateralYN,
    "BorrowerType": this.borrowerValue,
    "CollateralName": this.collateralName,
    "FirstLossPayee": this.firstLossPayee,
    "FleetOwnerYn": this.vehicleDetails?.FleetOwnerYn,
    "NoOfVehicles": this.vehicleDetails?.NoOfVehicles,
    "NoOfComprehensives": this.noOfCompPolicy,
    "ClaimRatio": this.claimRatio,
    "SavedFrom": this.motorDetails?.SavedFrom,
    "UserType": this.userType
    }
    ReqObj['FleetOwnerYn'] = "N";
    let urlLink = `${this.motorApiUrl}api/savemotordetails`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        let res:any = data;
        if(data.ErrorMessage.length!=0){
          if(res.ErrorMessage){
            // for(let entry of res.ErrorMessage){
            //   let type: NbComponentStatus = 'danger';
            //   const config = {
            //     status: type,
            //     destroyByClick: true,
            //     duration: 4000,
            //     hasIcon: true,
            //     position: NbGlobalPhysicalPosition.TOP_RIGHT,
            //     preventDuplicates: false,
            //   };
            //   this.toastrService.show(
            //     entry.Field,
            //     entry.Message,
            //     config);
            // }
          }
        }
        else{
          this.requestReferenceNo = data?.Result?.RequestReferenceNo;
           sessionStorage.setItem('quoteReferenceNo',data?.Result?.RequestReferenceNo);
          let entry = this.vehicleDetailsList[this.currentIndex-1];
          entry['PolicyEndDate'] = endDate;
          entry['PolicyStartDate'] = startDate;

          entry['InsuranceType'] = this.typeValue;
          entry['MSRefNo'] = data?.Result?.MSRefNo;
          entry['VdRefNo'] = data?.Result?.VdRefNo;
          entry['CdRefNo'] = data?.Result?.CdRefNo;
          entry['RequestReferenceNo'] = data?.Result?.RequestReferenceNo;
          entry['Active'] = true;
          entry['VehicleId'] = data.Result?.VehicleId;
          this.getCalculationDetails(entry,type);
          
        }

          // sessionStorage.setItem('editVehicleId',this.vehicleId);
          // sessionStorage.removeItem('vehicleDetails');
          // sessionStorage.setItem('vehChassisNo',this.vehicleDetails?.Chassisnumber);

          // this.getCalculationDetails(data?.Result);
      },
      (err) => { },
    );
  }
  onSelectVehicle(rowData){
    this.selectedVehicle = rowData;
    this.selectedVehicle['Active']=false;
    let k=0;
    if(this.vehicleDetailsList.length!=0){
      let i=0;
      for(let veh of this.vehicleDetailsList){
        if(i==0){
          this.selectedVehicle['PolicyStartDate'] = this.datePipe.transform(this.policyStartDate, "dd/MM/yyyy");
          this.selectedVehicle['PolicyEndDate'] = this.datePipe.transform(this.policyEndDate, "dd/MM/yyyy");
          this.selectedVehicle['Currency'] = this.currencyValue;
          this.selectedVehicle['ExchangeRate'] = this.exchangeRate;
          this.selectedVehicle['HavePromoCode'] = this.havePromoCodeYN;
          this.selectedVehicle['PromoCode'] = this.promoCode;
        }
        if(Number(veh.Vehicleid)>k) k=Number(veh?.Vehicleid);
        i+=1;
        if(i==this.vehicleDetailsList.length){
          this.selectedVehicle['Vehicleid'] = String(k+1);
        }
      }
    }
    else{
      this.selectedVehicle['Vehicleid'] = String(k+1);
    }
  }
  onDeleteVehicleWish(rowData){
    if(rowData.Active==false){
      let vehicleDetails = JSON.parse(sessionStorage.getItem('vehicleDetailsList'));
      if(vehicleDetails){
          vehicleDetails = vehicleDetails.filter(ele=>ele.ReqChassisNumber!=rowData.ReqChassisNumber);
          console.log("Filtered Vehicle",vehicleDetails);
         
          if(vehicleDetails.length==0){
            sessionStorage.removeItem('vehicleDetailsList');
            this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/customer-details']);
          }
          else{
            sessionStorage.setItem('vehicleDetailsList',JSON.stringify(vehicleDetails));
          }
      }
      if(this.vehicleId==rowData.Vehicleid){
        this.currentIndex = 1;
      }
      this.vehicleDetailsList = this.vehicleDetailsList.filter(ele=>ele.ReqChassisNumber!=rowData.ReqChassisNumber);

      this.totalCount = this.vehicleDetailsList.length;
      if(this.vehicleDetailsList.length==0){
        sessionStorage.removeItem('vehicleDetailsList');
        window.location.reload();
      }
    }
    else{
      let vehicleId = rowData.Vehicleid;
      let ReqObj = {
        "RequestReferenceNo": this.requestReferenceNo,
        "Vehicleid": vehicleId
      }
      let urlLink = `${this.motorApiUrl}api/deletemotordetails`;
      this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
        (data: any) => {
          let res:any = data;
          if(res?.Result){
            // let type: NbComponentStatus = 'success';
            //   const config = {
            //     status: type,
            //     destroyByClick: true,
            //     duration: 4000,
            //     hasIcon: true,
            //     position: NbGlobalPhysicalPosition.TOP_RIGHT,
            //     preventDuplicates: false,
            //   };
              this.vehicleDetailsList = this.vehicleDetailsList.filter(ele=>ele.ReqChassisNumber!=rowData.ReqChassisNumber);
              // this.toastrService.show(
              //   'Vehicle Details',
              //   'Vehicle Details Removed Successfully',
              //   config);
                this.totalCount = this.vehicleDetailsList.length;
                if(this.vehicleDetailsList.length==0){
                  sessionStorage.removeItem('vehicleDetailsList');
                  this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/customer-details']);
                }
                else{
                  this.vehicleDetailsList = this.vehicleDetailsList.filter(ele=>ele.Vehicleid!=rowData.Vehicleid);
                  sessionStorage.setItem('vehicleDetailsList',JSON.stringify(this.vehicleDetailsList));

                  window.location.reload();
                }

          }
        },
        (err) => { },
      );


    }
  }
  onAddVehicleWishList(){
    let list:any[] = this.vehicleDetailsList;
    let entry = this.vehicleDetailsList.find(ele=>ele.Chassisnumber == this.selectedVehicle.Chassisnumber);
    // let type: NbComponentStatus = 'danger';
    // const config = {
    //   status: type,
    //   destroyByClick: true,
    //   duration: 4000,
    //   hasIcon: true,
    //   position: NbGlobalPhysicalPosition.TOP_RIGHT,
    //   preventDuplicates: false,
    // };
    if(entry == undefined){

      this.vehicleDetailsList = [];
      this.vehicleDetailsList = list.concat([this.selectedVehicle]);
      this.vehicleDetails = null;
      sessionStorage.setItem('vehicleDetailsList',JSON.stringify(this.vehicleDetailsList))
      window.location.reload();
      console.log("Final List",this.vehicleDetailsList,this.totalCount,this.currentIndex)
    }
    else{
      // this.toastrService.show(
      //   'Chassis Number / Registration Number Already Available',
      //   'Duplicate Entry',
        
      //   config);
    }
    this.searchBy = ""; this.searchValue = null;this.selectedVehicle=null;
    this.customerData2 = [];
  }
  onVehicleValueChange (args) {
    if (args.key === 'e' || args.key === '+' || args.key === '-') {
      return false;
    } else {
      return true;
    }
  }
  CommaFormatted() {

    // format number
    if (this.vehicleSI) {
     this.vehicleSI = this.vehicleSI.replace(/\D/g, "")
       .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }}
    TppdCommaFormatted() {

      // format number
      if (this.tppdSI) {
       this.tppdSI = this.tppdSI.replace(/\D/g, "")
         .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      }}
    accessoriesCommaFormatted() {

      // format number
      if (this.accessoriesSI) {
       this.accessoriesSI = this.accessoriesSI.replace(/\D/g, "")
         .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      }
    }
    WindSICommaFormatted() {
      // format number
      if (this.windShieldSI) {
       this.windShieldSI = this.windShieldSI.replace(/\D/g, "")
         .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      }
    }
  onWindSIValueChange(event){
    this.windShieldSI = event;
  }
  getCalculationDetails(vehicleDetails,type){
    let createdBy="";
          let quoteStatus = sessionStorage.getItem('QuoteStatus');
          if(quoteStatus=='AdminRP'){
              createdBy = this.vehicleDetailsList[0].CreatedBy;
          }
          else{
            createdBy = this.loginId;
          }
    let ReqObj = {
        "InsuranceId": this.insuranceId,
        "BranchCode": this.branchCode,
        "AgencyCode": this.agencyCode,
        "SectionId": this.typeValue,
        "ProductId": this.productId,
        "MSRefNo": vehicleDetails?.MSRefNo,
        "VehicleId": vehicleDetails?.VehicleId,
        "CdRefNo": vehicleDetails?.CdRefNo,
        "VdRefNo": vehicleDetails?.VdRefNo,
        "CreatedBy": createdBy,
        "productId": this.productId,
        "sectionId": this.typeValue,
        "RequestReferenceNo": this.requestReferenceNo
    }
    let urlLink = `${this.CommonApiUrl}calculator/calc`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        let res:any = data;
        if(type=='save'){

        }
        else if(type=='proceedSave'){
          this.onFinalProceed();
        }
        else{

          if(this.currentIndex<this.totalCount){
            this.currentIndex = this.currentIndex+1;
              this.finalSection = false;
              if(this.vehicleDetailsList[this.currentIndex-1]?.Active==true){
                this.vehicleId = String(this.vehicleDetailsList[this.currentIndex-1].Vehicleid);
                this.getEditVehicleDetails(this.vehicleId,'direct');
                this.totalCount = this.vehicleDetailsList.length;
                $('#slider_0').removeClass('active w3-animate-left');
                $('#slider_0').removeClass('active w3-animate-right');
                $('#slider_0').addClass('active w3-animate-right');
              }
              else{

                this.vehicleDetails = this.vehicleDetailsList[this.currentIndex-1];
                this.motorDetails = this.vehicleDetailsList[this.currentIndex-1];
                this.totalCount = this.vehicleDetailsList.length;
                console.log("Motor Details",this.motorDetails);
                this.setVehicleValues('direct');
                //this.currencyValue = this.vehicleDetailsList[this.currentIndex-1].Currency;
                //this.onCurrencyChange();
                $('#slider_0').removeClass('active w3-animate-left');
                $('#slider_0').removeClass('active w3-animate-right');
                $('#slider_0').addClass('active w3-animate-right');
              }
          }
          else{
            this.finalSection = true;
          }

        }
        // sessionStorage.setItem('coverObject',JSON.stringify(data?.CoverList));
        // this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/excess-discount']);
        // console.log("Res",data);
      },
      (err) => { },
    );
  }
  getUWDetails(){
    let ReqObj = {
    "Limit":"0",
    "Offset":"100",
    "ProductId": this.productId,
    "LoginId": this.loginId,
    "InsuranceId": this.insuranceId,
    "BranchCode": this.branchCode
    }
    let urlLink = `${this.CommonApiUrl}master/getactiveuwquestions`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        let res:any = data.Result;
        if(res.length!=0){
          this.uwQuestionList = res;
          this.getEditUwQuestions();
        }
        else{
          this.getCurrencyList();
        }
      },
      (err) => { },
    );
  }
  getEditUwQuestions(){
    let ReqObj = {
      "InsuranceId": this.insuranceId,
      "ProductId": this.productId,
      "LoginId": this.loginId,
      "RequestReferenceNo": this.requestReferenceNo,   
      "VehicleId": "1"
    }
    let urlLink = `${this.CommonApiUrl}api/getuwquestionsdetails`;
    this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
      (data: any) => {
        let uwList = data?.Result;
        if(uwList.length!=0){
          let i=0;
          for(let ques of uwList){
            let entry = this.uwQuestionList.find(ele=>ele.UwQuestionId == ques.UwQuestionId);
            if(entry){ entry.Value = ques.Value};
            i+=1;
            if(i==uwList.length){
              this.uwQuestionList.forEach(x =>  {
                x.Value = x.Value ? '' || 'N' : 'N'
             });
              this.questionSection = true; console.log("Final UW List",this.uwQuestionList); this.getCurrencyList();}
          }
        }
        else{
          this.uwQuestionList.forEach(x =>  {
                x.Value = x.Value ? '' || 'N' : 'N'
             });
          this.questionSection = true;
          this.getCurrencyList();
        }
      },
      (err) => { },
    );
  }
  onStartDateChange(){
    console.log("Start Date",this.policyStartDate)
    var d = this.policyStartDate;
    var year = d.getFullYear();
    var month = d.getMonth();
    var day = d.getDate();
    this.endMinDate = new Date(this.policyStartDate);
    this.policyEndDate = new Date(year + 1, month, day-1);
    this.onChangeEndDate();
  }
  onCollateralChange(){
    console.log("final collateral",this.collateralYN);
    if(this.collateralValue) this.collateralYN = "Y";
    else this.collateralYN = "N";
  }
  onFleetChange(){
    this.noOfVehicles = null;this.noOfCompPolicy=null;this.claimRatio = null;
    if(this.fleetValue)this.fleetYN = "Y";
    else this.fleetYN = "N";
  }
  onGetBack(){
    this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/customer-details']);
    //sessionStorage.removeItem('vehicleDetailsList');
    // let value = sessionStorage.getItem('vehicleType');
    //   if(value=='edit'){

    //     this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/customer-details']);
    //   }
    //   if(value=='new'){
    //     this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/motor-details']);
    //   }
  }
  checkActiveVehicles(){
    if(this.vehicleDetailsList.length==0) return false;
    else if(this.vehicleDetailsList.length==1) return true;
    else {
      var exist=this.vehicleDetailsList.some(ele=>ele.Active==false);
      return !exist;
    }

  }
  onProceed(){
    if(this.vehicleDetailsList.length!=0){
      if(this.vehicleDetailsList.length==1){
        this.onFormSubmit('proceedSave');
      }
      else{
        this.onFinalProceed();
      }
    }

  }
  onFinalProceed(){
    let i=0,j=0;
    for(let veh of this.vehicleDetailsList){
      let refNo = veh?.MSRefNo;
      if(refNo == undefined){
        i+=1;
      }
      j+=1;
      if(j==this.vehicleDetailsList.length){
        console.log("Final I",i)
        if(i==0){
          sessionStorage.setItem('vehicleDetailsList',JSON.stringify(this.vehicleDetailsList));
          if(this.uwQuestionList.length!=0){
            let i = 0;
            let uwList:any[]=[];
            for(let ques of this.uwQuestionList){
              ques['BranchCode'] = this.branchCode;
              let createdBy="";
                let quoteStatus = sessionStorage.getItem('QuoteStatus');
                if(quoteStatus=='AdminRP'){
                    createdBy = this.vehicleDetailsList[0].CreatedBy;
                }
                else{
                  createdBy = this.loginId;
                }
              if(ques.QuestionType == '01'){
                
                ques['CreatedBy'] = createdBy;
                ques['RequestReferenceNo'] = this.requestReferenceNo;
                ques['UpdatedBy'] = this.loginId;
                ques["VehicleId"] = this.vehicleId
                uwList.push(ques);
              } 
              else if(ques.Value!=""){
                ques['CreatedBy'] = createdBy;
                ques['RequestReferenceNo'] = this.requestReferenceNo;
                ques['UpdatedBy'] = this.loginId;
                ques["VehicleId"] = this.vehicleId
                uwList.push(ques);
              } 
              i+=1;
              if(i==this.uwQuestionList.length) this.onSaveUWQues(uwList);
            }
          }
          else{
            this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/excess-discount']);
          }
          
        }
        else{
          console.log("Redirecting to Save Data");
          this.saveExistData();
        }
      }
    }

  }
  onSaveUWQues(uwList){
    if(uwList.length!=0){ 
      let urlLink = `${this.CommonApiUrl}api/saveuwquestions`;
      this.sharedService.onPostMethodSync(urlLink, uwList).subscribe(
        (data: any) => {
          if(data.Result){
              this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/excess-discount']);
          }
        },
        (err) => { },
      );
    }
  }
  saveExistData(){
    let i = 0;
    for(let veh of this.vehicleDetailsList){
      let refNo = veh?.MSRefNo;
      if(refNo == undefined){
        let reqRefNo = veh?.RequestReferenceNo;
        if(reqRefNo == undefined){
          reqRefNo = null;
        }
        this.vehicleId = String(veh.Vehicleid);
        let ReqObj =  {
          "RequestReferenceNo": veh.RequestReferenceNo,
           "Idnumber": this.customerDetails?.IdNumber,
          "Vehicleid": veh.Vehicleid
         }
         let urlLink = `${this.motorApiUrl}api/getmotordetails`;
        this.sharedService.onPostMethodSync(urlLink, ReqObj).subscribe(
          (data: any) => {
            if(data.Result){
              let vehicleDetails:any = data.Result;
              let startDate = "",endDate = ""
              //this.updateComponent.vehicleDetails = this.vehicleDetails;
              if(this.policyStartDate){
                startDate = this.datePipe.transform(this.policyStartDate, "dd/MM/yyyy");
              }
              if(this.policyEndDate){
                endDate = this.datePipe.transform(this.policyEndDate, "dd/MM/yyyy");
              }
              const oneday = 24 * 60 * 60 * 1000;
              const momentDate = new Date(this.policyEndDate); // Replace event.value with your date value
              const formattedDate = moment(momentDate).format("YYYY-MM-DD");
              const formattedDatecurrent = new Date(this.policyStartDate);
              console.log(formattedDate);
              let createdBy="";
              let quoteStatus = sessionStorage.getItem('QuoteStatus');
              if(quoteStatus=='AdminRP' || quoteStatus=='AdminRA' || quoteStatus=='AdminRR'){
                  createdBy = this.vehicleDetailsList[0].CreatedBy;
              }
              else{
                createdBy = this.loginId;
              }
              if(this.userType=='Broker'){
                this.brokerCode = this.agencyCode;
                createdBy = this.loginId;
                
                this.applicationId = "01";
              }
              this.subuserType = sessionStorage.getItem('typeValue');
              console.log("AcExecutive",this.acExecutiveId);
              if(vehicleDetails?.FleetOwnerYn==null) vehicleDetails.FleetOwnerYn = 'N';
              let appId = "1",loginId="",brokerbranchCode="";
              if(this.userType!='Issuer'){
                appId = "1"; loginId = this.loginId;
                brokerbranchCode = this.brokerbranchCode;
              }
              else{
                appId = this.loginId;
                brokerbranchCode = null;
              }
              console.log("Quote Status Received",quoteStatus)
              if(quoteStatus=='AdminRP' || quoteStatus=='AdminRA' || quoteStatus=='AdminRR'){
                brokerbranchCode = this.vehicleDetailsList[0].BrokerBranchCode;
              }
              console.log("AcExecutive",this.acExecutiveId);
              let ReqObj = {
                "BrokerBranchCode": brokerbranchCode,
              "AcExecutiveId": this.acExecutiveId,
              "CommissionType": this.commissionType,
              "BrokerCode": this.brokerCode,
              "LoginId": createdBy,
              "SubUserType": this.subuserType,
              "ApplicationId": this.applicationId,
              "CustomerReferenceNo": this.customerDetails?.CustomerReferenceNo,
              "RequestReferenceNo": veh.RequestReferenceNo,
              "Idnumber": this.customerDetails?.IdNumber,
              "VehicleId": veh.Vehicleid,
              "AcccessoriesSumInsured": vehicleDetails?.AcccessoriesSumInsured,
              "AccessoriesInformation": "",
              "AdditionalCircumstances": "",
              "AxelDistance": vehicleDetails?.AxelDistance,
              "Chassisnumber": vehicleDetails?.Chassisnumber,
              "Color": vehicleDetails?.Color,
              "CityLimit": vehicleDetails?.CityLimit,
              "CoverNoteNo": null,
              "OwnerCategory": vehicleDetails?.OwnerCategory,
              "CubicCapacity": vehicleDetails?.Grossweight,
              "CreatedBy": createdBy,
              "DrivenByDesc": this.drivenBy,
              "EngineNumber": vehicleDetails?.EngineNumber,
              "FuelType": vehicleDetails?.FuelType,
              "Gpstrackinginstalled": this.gpsYn,
              "Grossweight": vehicleDetails?.Grossweight,
              "HoldInsurancePolicy": "N",
              "Insurancetype": vehicleDetails?.Insurancetype,
              "InsuranceId": this.insuranceId,
              "InsuranceClass": vehicleDetails?.InsuranceClass,
              "InsurerSettlement": "",
              "InterestedCompanyDetails": "",
              "ManufactureYear": vehicleDetails?.ManufactureYear,
              "ModelNumber": null,
              "MotorCategory": vehicleDetails?.MotorCategory,
              "Motorusage": vehicleDetails?.Motorusage,
              "NcdYn": vehicleDetails?.NcdYn,
              "NoOfClaims": null,
              "NumberOfAxels": vehicleDetails?.NumberOfAxels,
              "BranchCode": this.branchCode,
              "AgencyCode": this.agencyCode,
              "ProductId": this.productId,
              "SectionId": vehicleDetails?.Insurancetype,
              "PolicyType": this.customerDetails?.PolicyHolderType,
              "RadioOrCasseteplayer": null,
              "RegistrationYear": this.customerDetails?.DobOrRegDate,
              "Registrationnumber": vehicleDetails?.Registrationnumber,
              "RoofRack": null,
              "SeatingCapacity": vehicleDetails?.SeatingCapacity,
              "SpotFogLamp": null,
              "Stickerno": null,
              "SumInsured": vehicleDetails?.SumInsured,
              "Tareweight": vehicleDetails?.Tareweight,
              "TppdFreeLimit": null,
              "TppdIncreaeLimit": vehicleDetails?.TppdIncreaeLimit,
              "TrailerDetails": null,
              "Vehcilemodel": vehicleDetails?.Vehcilemodel,
              "VehicleType": vehicleDetails?.VehicleType,
              "Vehiclemake": vehicleDetails?.Vehiclemake,
              "WindScreenSumInsured": vehicleDetails?.WindScreenSumInsured,
              "Windscreencoverrequired": null,
              "accident": null,
              "periodOfInsurance": this.noOfDays,
              "PolicyStartDate": startDate,
              "PolicyEndDate": endDate,
              "Currency" : this.currencyValue,
              "ExchangeRate": this.exchangeRate,
              "HavePromoCode": this.havePromoCodeYN,
              "PromoCode" : this.promoCode,
              "CollateralYn": vehicleDetails?.CollateralYn,
              "BorrowerType": vehicleDetails?.BorrowerType,
              "CollateralName": vehicleDetails?.CollateralName,
              "FirstLossPayee": vehicleDetails?.FirstLossPayee,
              "FleetOwnerYn": vehicleDetails?.FleetOwnerYn,
              "NoOfVehicles": vehicleDetails?.NoOfVehicles,
              "NoOfComprehensives": vehicleDetails?.NoOfComprehensives,
              "ClaimRatio": vehicleDetails?.ClaimRatio,
              "SavedFrom": vehicleDetails?.SavedFrom,
              "UserType": this.userType
              }
              let urlLink = `${this.motorApiUrl}api/savemotordetails`;
              this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
                (data: any) => {
                  let res:any = data;
                  if(data.ErrorMessage.length!=0){
                    if(res.ErrorMessage){
                      // for(let entry of res.ErrorMessage){
                      //   let type: NbComponentStatus = 'danger';
                      //   const config = {
                      //     status: type,
                      //     destroyByClick: true,
                      //     duration: 4000,
                      //     hasIcon: true,
                      //     position: NbGlobalPhysicalPosition.TOP_RIGHT,
                      //     preventDuplicates: false,
                      //   };
                      //   this.toastrService.show(
                      //     entry.Field,
                      //     entry.Message,
                      //     config);
                      // }
                    }
                  }
                  else{
                    this.requestReferenceNo = data?.Result?.RequestReferenceNo;
                     sessionStorage.setItem('quoteReferenceNo',data?.Result?.RequestReferenceNo);
                    veh['InsuranceType'] = vehicleDetails?.Insurancetype;
                    veh['MSRefNo'] = data?.Result?.MSRefNo;
                    veh['VdRefNo'] = data?.Result?.VdRefNo;
                    veh['CdRefNo'] = data?.Result?.CdRefNo;
                    veh['RequestReferenceNo'] = data?.Result?.RequestReferenceNo;
                    veh['Active'] = true;
                    console.log("Save Iterate",veh)
                    this.getCalculationDetails(veh,null);
                    i+=1;
                    if(i==this.vehicleDetailsList.length) this.onFinalProceed();

                    // sessionStorage.setItem('editVehicleId',this.vehicleId);
                    // sessionStorage.removeItem('vehicleDetails');
                    // sessionStorage.setItem('vehChassisNo',this.vehicleDetails?.Chassisnumber);

                    // this.getCalculationDetails(data?.Result);
                  }
                },
                (err) => { },
              );
            }
          },
          (err) => { },
        );
      }

    }
  }
}
