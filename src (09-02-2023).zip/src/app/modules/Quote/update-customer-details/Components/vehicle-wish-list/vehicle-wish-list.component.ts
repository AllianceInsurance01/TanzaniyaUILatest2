import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import * as Mydatas from '../../../../../app-config.json';
import { Router } from '@angular/router';
import { SharedService } from '../../../../../shared/shared.service';
import { DatePipe } from '@angular/common';
import { UpdateCustomerDetailsComponent } from '../../update-customer-details.component';

@Component({
  selector: 'app-vehicle-wish-list',
  templateUrl: './vehicle-wish-list.component.html',
  styleUrls: ['./vehicle-wish-list.component.scss']
})
export class VehicleWishListComponent implements OnInit {

  @Input('quoteRefNo') quoteRefNo: any;
  @Output('getBack') getBack = new EventEmitter();
  @Output('onWishListProceed') onWishListProceed = new EventEmitter();
  @Output('redirectCreateVehicle') redirectCreateVehicle = new EventEmitter();
  searchList:any[]=[];searchBy:any="";customerHeader:any[]=[];customerData:any[]=[];
  addSection:boolean = false;customerData2:any[]=[];customerHeader2:any[]=[];
  title: any;clientName: any;dateOfBirth: any;productValue:any;
  emailId: any;mobileNo: any;idNumber: any;productList:any[]=[];
  searchValue: string= "";vehicleWishList:any[]=[];minDate:Date;
  public AppConfig: any = (Mydatas as any).default;
  public ApiUrl1: any = this.AppConfig.ApiUrl1;
  public CommonApiUrl: any = this.AppConfig.CommonApiUrl;
  public motorApiUrl:any = this.AppConfig.MotorApiUrl;
  vehicleDetails: any;searchSection:boolean = false;
  referenceNo: any=null;wishSection:boolean = false;
  customerHeader3:any[]=[];noOfDays:any;minCurrencyRate:any;maxCurrencyRate:any;
  currencyList:any[]=[];exchangeRate:any;productId:any;policyStartDate:any;executiveValue:any;
  emptySection: boolean = false;userDetails:any;currencyCode:any;policyEndDate:any;commissionValue:any;
  loginId:any;userType:any;agencyCode:any;branchCode:any;insuranceId:any;commissionTypeList:any[]=[];
  endMinDate: Date;adminSection:boolean = false;issuerSection:false;executiveList:any[]=[];
  maxDate: Date;Code:any;brokerList:any[]=[];subUsertype:any;executiveSection:boolean=false;
  customerDetails:any;statusValue:any;HavePromoCode:any="N";PromoCode:any;
  editSection:boolean=true;
  code:any;
  acExecutiveId: any;
  commissionType: any;
  constructor(private router:Router,private sharedService: SharedService,private datePipe:DatePipe,
    private updateComponent:UpdateCustomerDetailsComponent) {
      this.customerHeader =  [
        { key: 'Chassisnumber', display: 'Chassis Number' },
        { key: 'PolicyTypeDesc', display: 'Policy Type' },
        
        { key: 'OverallPremiumFc', display: 'Premium' },
        { key: 'Vehiclemake', display: 'Make' },
        { key: 'Vehcilemodel', display: 'Model' },
        { key: 'Status', display: 'Status' },
        {
          key: 'actions',
          display: 'Action',
          config: {
            isEdit: true,
          },
        },

      ];
      this.customerHeader2 =  [
        {
          key: 'actions',
          display: 'Select',
          config: {
            select: true,
          },
        },
        { key: 'ReqChassisNumber', display: 'Chassis Number' },
        { key: 'Registrationnumber', display: 'Registration No' },
        { key: 'Vehiclemake', display: 'Make' },
        { key: 'Vehcilemodel', display: 'Model' },
        { key: 'Status', display: 'Status' },


      ];
      this.customerHeader3 =  [
        { key: 'ReqChassisNumber', display: 'Chassis Number' },
        { key: 'Registrationnumber', display: 'Registration No' },
        { key: 'Vehiclemake', display: 'Make' },
        { key: 'Vehcilemodel', display: 'Model' },
        { key: 'Status', display: 'Status' },
        {
          key: 'actions',
          display: 'Action',
          config: {
            isRemove: true,
          },
        },

      ];
      this.searchList = [
        { "Code":"","CodeDesc":"---Select---"},
        { "Code":"02","CodeDesc":"Register Number"},
        { "Code":"01","CodeDesc":"Chassis Number"},

      ];
     }

  ngOnInit(): void {
    let referenceNo =  sessionStorage.getItem('quoteReferenceNo');
      if(referenceNo){
        this.quoteRefNo = referenceNo;
      }
    if(this.quoteRefNo){
      console.log("Quote Exist Section",this.quoteRefNo)
      this.wishSection = true;
      this.getExistingVehiclesList();
    }
    else{
      if(this.updateComponent.vehicleWishList.length!=0){
        this.updateComponent.CurrencyCode = this.updateComponent.vehicleWishList[0].Currency;
        this.currencyCode = this.updateComponent.vehicleWishList[0].Currency;
        this.exchangeRate = this.updateComponent.vehicleWishList[0].ExchangeRate;
        this.policyStartDate = this.updateComponent.vehicleWishList[0].PolicyStartDate;
        this.policyEndDate = this.updateComponent.vehicleWishList[0].PolicyEndDate;
        this.HavePromoCode = this.updateComponent.vehicleWishList[0].HavePromoCode;
        this.PromoCode = this.updateComponent.vehicleWishList[0].PromoCode;
        this.acExecutiveId = this.updateComponent.vehicleWishList[0].AcExecutiveId;
        this.commissionType = this.updateComponent.vehicleWishList[0].CommissionType;
      }
      this.vehicleWishList = this.updateComponent.vehicleWishList;
      console.log("Vehicle Wishes",this.vehicleWishList,this.updateComponent.policyStartDate,this.updateComponent.policyEndDate,
      this.updateComponent.HavePromoCode,this.updateComponent.PromoCode)
      if(this.vehicleWishList.length==0) this.searchSection = true;
      else this.wishSection = true;
    }
  }
  getExistingVehiclesList(){
    let ReqObj = {
      "RequestReferenceNo": this.quoteRefNo
    }
    let urlLink = `${this.motorApiUrl}api/getallmotordetails`;
    this.sharedService.onPostMethodSync(urlLink, ReqObj).subscribe(
      (data: any) => {
        console.log(data);
        if(data.Result){
            this.customerData = data.Result;
            if(this.customerData.length!=0){
              this.updateComponent.CurrencyCode = this.customerData[0].Currency;
              this.currencyCode = this.customerData[0].Currency;
              this.exchangeRate = this.customerData[0].ExchangeRate;
              this.policyStartDate = this.customerData[0].PolicyStartDate;
              this.policyEndDate = this.customerData[0].PolicyEndDate;
              this.HavePromoCode = this.customerData[0].HavePromoCode;
              this.PromoCode = this.customerData[0].PromoCode;
              this.acExecutiveId = this.customerData[0].AcExecutiveId;
              this.commissionType = this.customerData[0].CommissionType;
              this.updateComponent.setCommonValues(this.customerData[0]);
            }
        }
      },
      (err) => { },
    );
  }
  onAddVehicleWishList(){
    this.wishSection = false;
    // let type: NbComponentStatus = 'danger';
    // const config = {
    //   status: type,
    //   destroyByClick: true,
    //   duration: 4000,
    //   hasIcon: true,
    //   position: NbGlobalPhysicalPosition.TOP_RIGHT,
    //   preventDuplicates: false,
    // };
    let list:any[] = this.vehicleWishList;
    let entry = this.vehicleWishList.find(ele=>ele.ReqChassisNumber == this.vehicleDetails.ReqChassisNumber);
    console.log(entry,this.vehicleDetails)
    if(entry == undefined){
      let existEntry = this.customerData.find(ele=>ele.Chassisnumber == this.vehicleDetails.ReqChassisNumber);
      if(existEntry==undefined){
        this.vehicleWishList = [];
        this.vehicleWishList = list.concat([this.vehicleDetails]);
        this.updateComponent.vehicleWishList = this.vehicleWishList;
        this.wishSection = true;
        this.vehicleDetails = null;
      }
      else{
        this.vehicleDetails = null;
      this.wishSection = true;
        // this.toastrService.show(
        //   'Chassis Number / Registration Number Already Available',
        //   'Duplicate Entry',
        //   config);
      }
    }
    else{
      this.vehicleDetails = null;
      this.wishSection = true;
      // this.toastrService.show(
      //   'Chassis Number / Registration Number Already Available',
      //   'Duplicate Entry',
      //   config);
    }
    this.searchBy = ""; this.searchValue = "";
    this.customerData2 = [];
    console.log(entry,this.vehicleDetails,this.vehicleWishList)
  }
  onEditVehicle(rowData){
    if(this.statusValue=='RA'){
      this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/excess-discount'])
    }
    else{
      // if(rowData.SavedFrom == 'Customer'){
      //   sessionStorage.setItem('vehicleType','new');
      //   this.updateComponent.resetVehicleTab();
      //   sessionStorage.setItem('editVehicleDetails',rowData.Chassisnumber)
      //   sessionStorage.setItem('editVehicleId',String(rowData.Vehicleid));
      //   this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/motor-details'])




      // }
      // else{
        sessionStorage.setItem('vehicleType','edit');
        this.updateComponent.resetVehicleTab();
         sessionStorage.setItem('editVehicleId',String(rowData.Vehicleid));
         this.setVehicleList('direct',null);
         this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/vehicle-details'])



      //}
    }

  }
  onCreateVehicle(){
    // let type: NbComponentStatus = 'danger';
    //   const config = {status: type,destroyByClick: true,duration: 4000,
    //     hasIcon: true,position: NbGlobalPhysicalPosition.TOP_RIGHT,
    //     preventDuplicates: false,};
        this.policyStartDate = this.updateComponent.policyStartDate;
        this.policyEndDate = this.updateComponent.policyEndDate;
        this.currencyCode = this.updateComponent.CurrencyCode;
        this.exchangeRate = this.updateComponent.exchangeRate;
        this.HavePromoCode = this.updateComponent.HavePromoCode;
        this.PromoCode = this.updateComponent.PromoCode;
          let vehicleData = {
            "vehicleWishList":this.vehicleWishList,
            "customerData": this.customerData
          }
          this.redirectCreateVehicle.emit(vehicleData);
  }
  createVehicleProceed(){
    let i=0,vehicleList:any[]=[],k=0;
    if(this.customerData.length!=0){
      for(let veh of this.customerData){
        veh['Active'] = true;
        vehicleList.push(veh);
        if(veh.Vehicleid>0 && veh.Vehicleid>k) k=veh.Vehicleid;
        i+=1;
        if(i==this.customerData.length){
          if(this.vehicleWishList.length!=0){
            let j=0;
            for(let vehicle of this.vehicleWishList){
              let m = k+1;
              vehicle['PolicyStartDate'] = this.datePipe.transform(this.policyStartDate, "dd/MM/yyyy");
              vehicle['PolicyEndDate'] = this.datePipe.transform(this.policyEndDate, "dd/MM/yyyy");
              vehicle['Currency'] = this.currencyCode;
              vehicle['HavePromoCode'] = this.HavePromoCode;
              vehicle['PromoCode'] = this.PromoCode;
              vehicle['ExchangeRate'] = this.exchangeRate;
              vehicle['Vehicleid'] = String(m);
              vehicle['Active'] = false;
              vehicleList.push(vehicle);
              j+=1;
              if(j==this.vehicleWishList.length){
                sessionStorage.setItem('vehicleDetailsList',JSON.stringify(vehicleList));
                sessionStorage.setItem('vehicleLength',String(m+1))
                sessionStorage.setItem('vehicleType','new');
                sessionStorage.removeItem('vehicleDetails');
                this.updateComponent.resetVehicleTab();
                this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/motor-details'])
              }
            }
          }
          else{
                sessionStorage.setItem('vehicleDetailsList',JSON.stringify(vehicleList));
                sessionStorage.setItem('vehicleLength',String(vehicleList.length))
                sessionStorage.setItem('vehicleType','new');
                sessionStorage.removeItem('vehicleDetails');
                this.updateComponent.resetVehicleTab();
                this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/motor-details'])
          }
        }
      }
    }
    else{
      if(this.vehicleWishList.length!=0){
        let j=0;
        for(let vehicle of this.vehicleWishList){
          let m = k+1;
          vehicle['PolicyStartDate'] = this.datePipe.transform(this.policyStartDate, "dd/MM/yyyy");
          vehicle['PolicyEndDate'] = this.datePipe.transform(this.policyEndDate, "dd/MM/yyyy");
          vehicle['Currency'] = this.currencyCode;
          vehicle['HavePromoCode'] = this.HavePromoCode;
          vehicle['PromoCode'] = this.PromoCode;
          vehicle['ExchangeRate'] = this.exchangeRate;
          vehicle['Vehicleid'] = String(m);
          vehicle['Active'] = false;
          vehicleList.push(vehicle);
          j+=1;
          if(j==this.vehicleWishList.length){
            sessionStorage.setItem('vehicleDetailsList',JSON.stringify(vehicleList));
            sessionStorage.setItem('vehicleLength',String(m+1))
            sessionStorage.setItem('vehicleType','new');
            sessionStorage.removeItem('vehicleDetails');
            this.updateComponent.resetVehicleTab();
            this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/motor-details'])
          }
        }
      }
    }
  }
  onDeleteVehicleWish(rowData){
    let vehicleDetails = JSON.parse(sessionStorage.getItem('vehicleDetailsList'));
    if(vehicleDetails){
        vehicleDetails = vehicleDetails.filter(ele=>ele.ReqChassisNumber!=rowData.ReqChassisNumber);
        sessionStorage.setItem('vehicleDetailsList',JSON.stringify(vehicleDetails));
    }
    this.vehicleWishList = this.vehicleWishList.filter(ele=>ele.ReqChassisNumber!=rowData.ReqChassisNumber)
    if(this.vehicleWishList.length==0){
      this.searchSection = true;
    }
  }
  setVehicleList(type,id){
    if(type=='direct'){
      let k = 0,i=0,vehicleList=[];
      for(let veh of this.customerData){
        //veh['PolicyStartDate'] = this.datePipe.transform(this.policyStartDate, "dd/MM/yyyy");
        //veh['PolicyEndDate'] = this.datePipe.transform(this.policyEndDate, "dd/MM/yyyy");
        veh['PolicyStartDate']=this.policyStartDate;
        veh['PolicyEndDate']=this.policyEndDate;
        veh['Currency'] = this.currencyCode;
        veh['HavePromoCode'] = this.HavePromoCode;
        veh['PromoCode'] = this.PromoCode;
        veh['ExchangeRate'] = this.exchangeRate;
        veh['Active'] = true;
        vehicleList.push(veh);
        if(veh.Vehicleid>0) k=veh.Vehicleid;
        i+=1;
        if(i==this.customerData.length){
          if(this.vehicleWishList.length!=0){
            let j=0;
            for(let vehicle of this.vehicleWishList){
              vehicle['PolicyStartDate'] = this.datePipe.transform(this.policyStartDate, "dd/MM/yyyy");
              vehicle['PolicyEndDate'] = this.datePipe.transform(this.policyEndDate, "dd/MM/yyyy");
              vehicle['Currency'] = this.currencyCode;
              vehicle['ExchangeRate'] = this.exchangeRate;
              vehicle['Vehicleid'] = String(k+1);
              vehicle['Active'] = false;
              vehicleList.push(vehicle);
              j+=1;
              if(j==this.vehicleWishList.length){
                sessionStorage.setItem('vehicleDetailsList',JSON.stringify(vehicleList));
                sessionStorage.setItem('vehicleType','edit');
                this.updateComponent.resetVehicleTab();
                sessionStorage.removeItem('vehicleDetails');
                this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/vehicle-details'])
              }
            }
          }
          else{

                sessionStorage.setItem('vehicleDetailsList',JSON.stringify(vehicleList));
                sessionStorage.setItem('vehicleType','edit');
                this.updateComponent.resetVehicleTab();
                sessionStorage.removeItem('vehicleDetails');
                this.router.navigate(['/Home/existingQuotes/customerSelection/customerDetails/vehicle-details'])
          }
        }
      }
    }
  }
  onSearchVehicle(){
    this.customerData2 = [];
    // let type: NbComponentStatus = 'danger';
    // const config = {status: type,destroyByClick: true,duration: 4000,
    //   hasIcon: true,position: NbGlobalPhysicalPosition.TOP_RIGHT,
    //   preventDuplicates: false,};
    if(this.searchBy!='' && this.searchBy!=null && this.searchBy!=undefined){
      let chassisNo = "",regNo = "";
      if(this.searchBy=='01'){
        chassisNo = this.searchValue
      }
      else{
        regNo = this.searchValue;
      }

      if(this.searchValue=='' || this.searchValue==undefined || this.searchValue==null){
        if(this.searchBy=='01'){
        //this.toastrService.show('SearchValue','Please Enter ChassisNumber',config);
        }
        else if(this.searchBy=='02'){
          //this.toastrService.show('SearchValue','Please Enter RegistrationNumber',config);
          }
      }
      else{
        let ReqObj = {
          "ReqChassisNumber": chassisNo,
          "ReqRegNumber": regNo
        }
        let urlLink = `${this.motorApiUrl}regulatory/showvehicleinfo`;
        this.sharedService.onPostMethodSync(urlLink, ReqObj).subscribe(
          (data: any) => {
            console.log(data);
            if(data.Result){
                this.customerData2 = [data?.Result];
                this.emptySection = false;
            }
            else if(data.ErrorMessage){
              if(data.ErrorMessage){
                this.emptySection = true;
                console.log("Error Iterate",data.ErrorMessage)
              }
          }
          },
          (err) => { },
        );
      }

    }
    else{
      //this.toastrService.show('SearchType','Please Select Search Type',config);
    }
  }
  onSelectVehicle(rowData){
    this.vehicleDetails = rowData;
  }
  ongetBack(){
    this.getBack.emit();
  }
  WishListProceed(){
    console.log("Wish List 1");
      this.onWishListProceed.emit(this.customerData);
  }
}
