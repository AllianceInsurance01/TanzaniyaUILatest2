import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-view-details',
  templateUrl: './new-view-details.component.html',
  styleUrls: ['./new-view-details.component.scss']
})
export class NewViewDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
