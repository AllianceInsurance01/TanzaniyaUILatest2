export class Product {
	ref: any = null
	ts: number = 0
	data: ProductData = null

	constructor(data) {
		this.ref = data.ref
		this.ts = data.ts
		const product = { ...data.data }
		product.id = data.ref['@ref'].id
		this.data = new ProductData(product)
	}
}

export class ProductData {
	
	id: string = '';
	CustomerName: string = '';
	Dob:any = '';
	OccupationType:any='';
	SalaryPerAnnum:any='';
	BenefitCoverMonth:any='';
	SumInsured:any='';
    SectionId: string='';
    IdProofType:string = '';
    IdNo:string = '';
    JobJoiningMonth:string = '';
    BetweenDiscontinued:string="N";
    EthicalWorkInvolved:string='N';

	constructor(data?) {
		this.id = data?.id ?? ''
		this.CustomerName = data?.CustomerName ?? '';
		this.Dob = data?.Dob ?? '';
		this.OccupationType = data?.OccupationType ?? '';
		this.SalaryPerAnnum = data?.SalaryPerAnnum ?? '';
		this.BenefitCoverMonth = data?.BenefitCoverMonth ?? '';
		this.SumInsured = data?.SumInsured ?? '';
		this.SectionId = data?.SectionId ?? '';
		this.IdProofType = data?.IdProofType ?? '';
		this.IdNo = data?.IdNo ?? '';
		this.JobJoiningMonth = data?.JobJoiningMonth ?? '';
		this.BetweenDiscontinued = data?.BetweenDiscontinued ?? '';
		this.EthicalWorkInvolved = data?.EthicalWorkInvolved ?? '';
	}
}
