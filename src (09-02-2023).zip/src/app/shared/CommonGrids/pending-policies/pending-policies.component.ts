import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pending-policies',
  templateUrl: './pending-policies.component.html',
  styleUrls: ['./pending-policies.component.scss']
})
export class PendingPoliciesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
