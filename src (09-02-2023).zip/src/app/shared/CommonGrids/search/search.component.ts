import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as Mydatas from '../../../app-config.json';
import { SharedService } from '../../../shared/shared.service';



@Component({
  selector: 'app-existing-customers',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {

  searchValue:any[]=[];columnHeader:any []=[];innerColumnHeader:any []=[];
  quoteData:any []=[];customerData:any[]=[];
  public AppConfig: any = (Mydatas as any).default;
  public ApiUrl1: any = this.AppConfig.ApiUrl1;
  public CommonApiUrl: any = this.AppConfig.CommonApiUrl;
  public motorApiUrl:any = this.AppConfig.MotorApiUrl;SearchList:any;
  public userDetails: any;loginId: any;agencyCode: any;branchCode: any;
  public brokerbranchCode: any;productId: any;insuranceId: any;userType: any;
  customerValue: boolean;
  referenceNo: string;search:any;
  constructor(private router:Router,private sharedService: SharedService) {
    this.userDetails = JSON.parse(sessionStorage.getItem('Userdetails'));
    this.loginId = this.userDetails.Result.LoginId;
    this.agencyCode = this.userDetails.Result.OaCode;
    this.branchCode = this.userDetails.Result.BranchCode;
    this.brokerbranchCode = this.userDetails.Result.BrokerBranchCode;
    this.productId = this.userDetails.Result.ProductId;
    this.insuranceId = this.userDetails.Result.InsuranceId;
    this.userType = this.userDetails.Result.UserType;

    this.columnHeader =  [
      { key: 'QuoteNo', display: 'Quote No' },
      { key: 'RequestReferenceNo', display: 'Reference No' },
      { key: 'ClientName', display: 'Customer Name' },
     
      {
        key: 'actions',
        display: 'Action',
        config: {
          isEdit: true,
        },
      },
    ];
    this.columnHeader =  [
      { key: 'Registrationnumber', display: 'Registration No' },
      { key: 'Chassisnumber', display: 'Chassis No' },
      { key: 'Vehiclemake', display: 'Make' },
      { key: 'Vehcilemodel', display: 'Model' },
      { key: 'ClientName', display: 'Customer Name' },
      { key: 'CreatedBy', display: 'Created By' },
      
      
      // {
      //   key: 'actions',
      //   display: 'Action',
      //   config: {
      //     isEdit: true,
      //   },
      // },
      
    ];
    this.getCustomersList();
   }

  ngOnInit(): void {
    let refno = sessionStorage.getItem('customerReferenceNo')
    if (refno){
      this.customerValue=true;
      this.referenceNo = refno;
    }
    console.log(refno);
  }
  getCustomersList(){
      let ReqObj = {
        "InsuranceId":this.insuranceId,
        "BranchCode":this.branchCode,
        "ProductId":this.productId
      }
      let urlLink = `${this.CommonApiUrl}api/dropdown/copyquoteby`;
      this.sharedService.onPostMethodSync(urlLink,ReqObj).subscribe(
        (data: any) => {
          console.log(data);
          if(data.Result){
             this.SearchList = data.Result;
             //this.onCustomerSearch()
      
          }
        },
        (err) => { },
      );
  }
  
  onCustomerSearch(){
   
    if(this.searchValue){
      this.customerData = [];
      let ReqObj = {
        "SearchKey":this.search,
        "SearchValue":this.searchValue,
        "LoginId":this.loginId,
        "InsuranceId":this.insuranceId,
        "BranchCode":this.branchCode,
        //"BrokerBranchCode":this.brokerbranchCode,
        "ProductId":this.productId,
        "UserType":this.userType,
        "ApplicationId":"1"
      }
      let urlLink = `${this.CommonApiUrl}api/searchmotordata`;
      this.sharedService.onPostMethodSync(urlLink, ReqObj).subscribe(
        (data: any) => {
          console.log(data);
          if(data.Result){
              this.customerData=data.Result;
          }
        },
        (err) => { },
      );
    }
  } 
 
}
