import { Component, OnInit } from '@angular/core'
import { ProductData } from '../../models/product'
import { ProductService } from '../../service/product.service'
import { Router, ActivatedRoute } from '@angular/router'
import { FormGroup } from '@angular/forms'
import { FormlyFieldConfig } from '@ngx-formly/core'
import { ToastrService } from 'ngx-toastr'
import { DatePipe } from '@angular/common'

@Component({
	selector: 'app-product-form',
	templateUrl: './product-form.component.html',
	styleUrls: ['./product-form.component.scss'],
})
export class ProductFormComponent implements OnInit {
	public id: string = ''
	public productItem: ProductData = null
	public productProps: string[] = []
	public CommonApiUrl: any = "http://192.168.1.42:8086/";
	public form = new FormGroup({})
	public model = {}
	public fields: FormlyFieldConfig[] = [];
	customerReferenceNo: any=null;
	policyHolderTypeList: any
	dob: string
	policyHolderList: any
	titleList: any
	countryList: any
	genderList: any
	occupationList: any
	businessTypeList: any
	stateList: any

	constructor(private product: ProductService,private datePipe:DatePipe,private route:ActivatedRoute,
	private router: Router) {
		this.fields =  [
			{
			  type: 'stepper',
			  fieldGroup: [
				
				{
				  props: { label: 'Client Details' },
				  fieldGroup: [
					{
					  fieldGroupClassName: 'row',
					  fieldGroup: [
						  
						{
						  className: 'col-2',
						  key: 'Title',
						  type: 'select',
						  props: {
							label: 'Title',
							options: [
							  { label: 'Mr', value: '1' },
							  { label: 'Ms', value: '2' },
							  { label: 'Dr', value: '3' },
							  { label: 'Mrs', value: '4' },
							],
						  },
						},
						{
						  className: 'col-4',
						  type: 'input',
						  key: 'ClientName',
						  props: {
							label: 'Customer Name',
						  },
						},
						{
						  className: 'col-6',
						  type: 'select',
						  key: 'IdType',
						  props: {
							label: 'Customer Type',
							options: [
							],
						  },
						  
						  expressions: {
							'props.disabled': '!model.ClientName',
						  },
						  hooks: {
							onInit: (field: FormlyFieldConfig) => {
								field.formControl.valueChanges.subscribe(() => {
									this.getPolicyIdTypeList(null);
								});
							},
						  }
						},
					  ]
					},
					{
					  fieldGroupClassName: 'row',
					  fieldGroup: [
						{
						  className: 'col-md-6 col-lg-6 col-xl-6',
						  type: 'select',
						  key: 'PolicyHolderTypeid',
						  props: {
							label: 'Policy Holder Type',
							options: [
							  
							],
						  },
						  
						  expressions: {
							'props.disabled': '!model.IdType',
						  },
						},
						{
						  className: 'col-6',
						  type: 'input',
						  key: 'IdNumber',
						  props: {
							label: 'ID Number',
						  },
						},
						{
						  className: 'col-6',
						  key: 'dobOrRegDate',
						  type: 'input',
						  props: {
							label: 'Registration Date(Choose Back Date )',
							type: 'date',
							datepickerOptions: {
								max: new Date(),
							  },
						  }
						},
						{
						  className: 'col-6',
						  key: 'AppointmentDate',
						  type: 'input',
						  props: {
							label: 'Appointment Date (Choose Future Date)',
							type: 'date',
						  }
						},
						{
						  className: 'col-2',
						  key: 'isTaxExempted',
						  type: 'select',
						  props: {
							label: 'Tax Excempted (select no)',
							options: [
							  { label: 'Yes', value: 'Y' },
							  { label: 'No', value: 'N' }
							],
						  },
						},
						{
						  className: 'col-4',
						  key: 'PreferredNotification',
						  type: 'select',
						  props: {
							label: 'Prefered Notification',
							options: [
							  { label: 'SMS', value: 'sms' },
							  { label: 'Mail', value: 'mail' },
							  { label: 'Whatsapp', value: 'whatsapp' }
							],
						  },
						},
						{
						  className: 'col-6',
						  key: 'Clientstatus',
						  type: 'select',
						  props: {
							label: 'Status',
							options: [
							  { label: 'Active', value: 'Y' },
							  { label: 'DeActive', value: 'N' },
							  { label: 'Pending', value: 'P' }
							],
						  },
						},
					  ]
					},
				  ],
				  
				},
				{
				  props: { label: 'Client Type' },
				  fieldGroup: [
					{
					  fieldGroupClassName: 'row',
					  fieldGroup: [
						{
						  className: 'col-6',
						  type: 'select',
						  key: 'Country',
						  props: {
							label: 'Country',
							options: [
							 
							],
						  },
						  hooks: {
							onInit: (field: FormlyFieldConfig) => {
								field.formControl.valueChanges.subscribe(() => {
									this.getStateList();
								});
							},
						  },
						  expressions: {
							'props.disabled': '!model.IdType',
						  },
						},
						{
						  className: 'col-6',
						  type: 'select',
						  key: 'Gender',
						  props: {
							label: 'Gender',
							options: [
							  
							],
						  },
						  expressions: {
							'props.disabled': '!model.IdType',
						  },
						},
						{
						  className: 'col-6',
						  type: 'select',
						  key: 'Occupation',
						  props: {
							label: 'Occupation',
							options: [
							 
							],
						  },
						  expressions: {
							'props.disabled': '!model.IdType',
						  },
						},
						{
						  className: 'col-6',
						  type: 'input',
						  key: 'vrngst',
						  props: {
							label: 'VRN/GST No',
						  },
						},
					  ]
					}
				  ],
				},
				{
				  props: { label: 'Address Details' },
				  fieldGroup: [
					{
					  fieldGroupClassName: 'row',
					  fieldGroup: [
						{
						  className: 'col-4',
						  type: 'select',
						  key: 'state',
						  props: {
							label: 'State',
							options: [
							  
							],
						  },
						  expressions: {
							'props.disabled': '!model.IdType',
						  },
						},
						{
						  className: 'col-4',
						  type: 'input',
						  key: 'CityName',
						  props: {
							label: 'City',
						  },
						},
						{
						  className: 'col-4',
						  type: 'input',
						  key: 'Street',
						  props: {
							label: 'Street',
						  },
						},
						{
						  className: 'col-4',
						  type: 'input',
						  key: 'Address1',
						  props: {
							label: 'Address1',
						  },
						},
						{
						  className: 'col-4',
						  type: 'input',
						  key: 'Address2',
						  props: {
							label: 'Address2',
						  },
						},
						{
						  className: 'col-4',
						  type: 'input',
						  key: 'TelephoneNo',
						  props: {
							label: 'Telephone No',
						  },
						},
						{
						  className: 'col-4',
						  type: 'input',
						  key: 'MobileNo',
						  props: {
							label: 'Mobile No',
						  },
						},
						{
						  className: 'col-4',
						  type: 'input',
						  key: 'EmailId',
						  props: {
							label: 'EmailId',
						  },
						},
					  ]
					}
				  ],
				},
			  ],
			},
		  ];
		let refNo = sessionStorage.getItem('customerReferenceNo');
		if(refNo){
			this.customerReferenceNo = refNo;
		}
		else{
			this.customerReferenceNo = null;
			this.productItem = new ProductData()
		}
		this.getTitleList();
	}

	public ngOnInit(): void {
		
	}
	getTitleList(){
		let ReqObj = {
		  "InsuranceId": "100002",
		  "BranchCode": "02"
		}
		let urlLink = `${this.CommonApiUrl}dropdown/title`;
		this.product.onPostMethodSync(urlLink,ReqObj).subscribe(
		  (data: any) => {
			if(data.Result){
				let obj = [{"Code":null,"CodeDesc":"-Select-"}]
			   this.titleList = obj.concat(data.Result);
			   for(let i = 0; i < this.titleList.length; i++){
				this.titleList[i].label = this.titleList[i]['CodeDesc'];
				this.titleList[i].value = this.titleList[i]['Code'];
					delete this.titleList[i].CodeDesc;
					if(i==this.titleList.length-1){
						this.fields[0].fieldGroup[0].fieldGroup[0].fieldGroup[0].props.options = this.titleList;
			   			this.getPolicyHolderList();
					}
				}
			   
			}
		  },
		  (err) => { },
		);
	  }
	  getPolicyHolderList(){
		let ReqObj = {
		  "InsuranceId": "100002",
		  "BranchCode": "02"
		}
	
		let urlLink = `${this.CommonApiUrl}dropdown/policyholdertype`;
		this.product.onPostMethodSync(urlLink,ReqObj).subscribe(
		  (data: any) => {
			console.log(data);
			if(data.Result){
			   this.policyHolderList = data.Result;
			   for(let i = 0; i < this.policyHolderList.length; i++){
				this.policyHolderList[i].label = this.policyHolderList[i]['CodeDesc'];
				this.policyHolderList[i].value = this.policyHolderList[i]['Code'];
					delete this.policyHolderList[i].CodeDesc;
					if(i==this.policyHolderList.length-1){
						console.log("Fields",this.fields)
						this.fields[0].fieldGroup[0].fieldGroup[0].fieldGroup[2].props.options = this.policyHolderList;
						this.getCountryList();
					}
				}
			   
			   //this.getPolicyIdTypeList();
			}
		  },
		  (err) => { },
		);
	  }
	  getCountryList(){
		let ReqObj = {
		  "InsuranceId": "100002",
		  "BranchCode": "02"
		}
		let urlLink = `${this.CommonApiUrl}master/dropdown/country`;
		this.product.onPostMethodSync(urlLink,ReqObj).subscribe(
		  (data: any) => {
			console.log(data);
			if(data.Result){
			   this.countryList = data.Result;
			   for(let i = 0; i < this.countryList.length; i++){
				this.countryList[i].label = this.countryList[i]['CodeDesc'];
				this.countryList[i].value = this.countryList[i]['Code'];
					delete this.countryList[i].CodeDesc;
					if(i==this.countryList.length-1){
						console.log("County Fields",this.fields)
						this.fields[0].fieldGroup[1].fieldGroup[0].fieldGroup[0].props.options = this.countryList;
						this.getGenderList();
					}
				}
			   //this.getGenderList();
			}
		  },
		  (err) => { },
		);
	  }
	  getGenderList(){
		let ReqObj = {
		  "InsuranceId": "100002",
		  "BranchCode": "02",
		}
		let urlLink = `${this.CommonApiUrl}dropdown/policyholdergender`;
		this.product.onPostMethodSync(urlLink,ReqObj).subscribe(
		  (data: any) => {
			console.log(data);
			if(data.Result){
			   this.genderList = data.Result;
			   for(let i = 0; i < this.genderList.length; i++){
				this.genderList[i].label = this.genderList[i]['CodeDesc'];
				this.genderList[i].value = this.genderList[i]['Code'];
					delete this.genderList[i].CodeDesc;
					if(i==this.genderList.length-1){
						console.log("County Fields",this.fields)
						this.fields[0].fieldGroup[1].fieldGroup[0].fieldGroup[1].props.options = this.genderList;
						this.getOccupationList();
						
					}
				}
			}
		  },
		  (err) => { },
		);
	  }
	  getOccupationList(){
		let ReqObj = {
		  "InsuranceId": "100002",
		  "BranchCode": "02",
		
		}
		let urlLink = `${this.CommonApiUrl}master/dropdown/occupation`;
		this.product.onPostMethodSync(urlLink,ReqObj).subscribe(
		  (data: any) => {
			console.log(data);
			if(data.Result){
			   this.occupationList = data.Result;
			   for(let i = 0; i < this.occupationList.length; i++){
				this.occupationList[i].label = this.occupationList[i]['CodeDesc'];
				this.occupationList[i].value = this.occupationList[i]['Code'];
					delete this.occupationList[i].CodeDesc;
					if(i==this.occupationList.length-1){
						console.log("County Fields",this.fields)
						this.fields[0].fieldGroup[1].fieldGroup[0].fieldGroup[2].props.options = this.occupationList;
						if(this.customerReferenceNo){
							this.setValues();
						}
						//this.getBusinessTypeList();
						
					}
				}
			}
		  },
		  (err) => { },
		);
	  }
	  getBusinessTypeList(){
		let ReqObj = {
		  "InsuranceId": "100002",
		  "BranchCode": "02",
		}
		let urlLink = `${this.CommonApiUrl}dropdown/businesstype`;
		this.product.onPostMethodSync(urlLink,ReqObj).subscribe(
		  (data: any) => {
			console.log(data);
			if(data.Result){
			   this.businessTypeList = data.Result;
			   for(let i = 0; i < this.businessTypeList.length; i++){
				this.businessTypeList[i].label = this.businessTypeList[i]['CodeDesc'];
				this.occupationList[i].value = this.businessTypeList[i]['Code'];
					delete this.businessTypeList[i].CodeDesc;
					if(i==this.businessTypeList.length-1){
						console.log("County Fields",this.fields)
						//this.fields[0].fieldGroup[1].fieldGroup[1].fieldGroup[0].props.options = this.businessTypeList;
						if(this.customerReferenceNo){
							this.setValues();
						}
						else{
							this.productItem = new ProductData();
						}
					}
				}
			}
		  },
		  (err) => { },
		);
	  }
	  getStateList(){
		let ReqObj = {
		  "CountryId": this.productItem.Country
		}
		let urlLink = `${this.CommonApiUrl}master/dropdown/state`;
		this.product.onPostMethodSync(urlLink,ReqObj).subscribe(
		  (data: any) => {
			console.log(data);
			if(data.Result){
			   this.stateList = data.Result;
			   for(let i = 0; i < this.stateList.length; i++){
				this.stateList[i].label = this.stateList[i]['CodeDesc'];
				this.stateList[i].value = this.stateList[i]['Code'];
					delete this.stateList[i].CodeDesc;
					if(i==this.stateList.length-1){
						console.log("County Fields",this.fields)
						 this.fields[0].fieldGroup[2].fieldGroup[0].fieldGroup[0].props.options = this.stateList;
						// this.getGenderList();
					}
				}
			   //this.getCityList();
			}
		  },
		  (err) => { },
		);
	  }
	  getPolicyIdTypeList(type){
		let ReqObj = {
		  "InsuranceId": "100002",
		  "BranchCode": "02",
		  "PolicyTypeId": this.productItem.IdType
		}
		let urlLink = `${this.CommonApiUrl}dropdown/policyholderidtype`;
		this.product.onPostMethodSync(urlLink,ReqObj).subscribe(
		  (data: any) => {
			console.log(data);
			if(data.Result){
			  //this.holderTypeValue = null;
			   this.policyHolderTypeList = data.Result;
			   for(let i = 0; i < this.policyHolderTypeList.length; i++){
				this.policyHolderTypeList[i].label = this.policyHolderTypeList[i]['CodeDesc'];
				this.policyHolderTypeList[i].value = this.policyHolderTypeList[i]['Code'];
					delete this.policyHolderTypeList[i].CodeDesc;
					if(i==this.policyHolderTypeList.length-1){
						console.log("Fields",this.fields[0].fieldGroup[0])
						this.fields[0].fieldGroup[0].fieldGroup[1].fieldGroup[0].props.options = this.policyHolderTypeList;
						if(type=='change') this.dob="";
					}
				}
			   
			}
		  },
		  (err) => { },
		);
	  }
	setValues(){
		let ReqObj = {
			"CustomerReferenceNo": this.customerReferenceNo
		}
		let urlLink = `${this.CommonApiUrl}api/getcustomerdetails`;
		this.product.onPostMethodSync(urlLink,ReqObj).subscribe(
		  (data: any) => {
			console.log(data);
			if(data.Result){
				let customerDetails= data.Result;
				this.productItem = new ProductData();
				this.productItem.ClientName = customerDetails.ClientName;
				if(customerDetails.AppointmentDate!=null && customerDetails.AppointmentDate!=undefined){
					var dateParts = customerDetails.AppointmentDate.split("/");
     				 this.productItem.AppointmentDate = dateParts[2]+'-'+dateParts[1]+'-'+dateParts[0];
				}
				this.productItem.Address1 = customerDetails.Address1;
				this.productItem.Address2 = customerDetails.Address2;
				this.productItem.CityName = customerDetails.CityName;
				this.productItem.Clientstatus = customerDetails.Clientstatus;
				this.productItem.EmailId = customerDetails.Email1;
				this.productItem.Country = customerDetails.Nationality;
				this.productItem.Gender = customerDetails.Gender;
				this.productItem.IdNumber = customerDetails.IdNumber;
				this.productItem.IdType = customerDetails.PolicyHolderType;
				this.productItem.isTaxExempted = customerDetails.IsTaxExempted;
				this.productItem.MobileNo = customerDetails.MobileNo1;
				this.productItem.Occupation = customerDetails.Occupation;
				this.productItem.PolicyHolderTypeid = customerDetails.PolicyHolderTypeid;
				this.productItem.PreferredNotification = customerDetails.PreferredNotification;
				this.productItem.state = customerDetails.StateCode;
				if(customerDetails.DobOrRegDate!=null && customerDetails.DobOrRegDate!=undefined){
					var dateParts = customerDetails.DobOrRegDate.split("/");
     				 this.productItem.dobOrRegDate = dateParts[2]+'-'+dateParts[1]+'-'+dateParts[0];
				}
				this.productItem.Street = customerDetails.Street;
				this.productItem.TelephoneNo = customerDetails.TelephoneNo1;
				this.productItem.Title = customerDetails.Title;
				this.productItem.vrngst = customerDetails.VrTinNo;
			}
		},
		(err) => { },
	  );
	}
	private getProduct() {
		if (this.id !== 'new') {
			this.product.getProductById(this.id).then((product) => {
				this.productItem = product
			})
		} else {
			this.productItem = new ProductData()
		}
	}
	onChange(event){
		console.log("Event on Change",event);
	}
	public async onSubmit(data) {
		console.log("Total Data",data)
		let appointmentDate="",dobOrRegDate="";
		 if(data.AppointmentDate!= undefined && data.AppointmentDate!=null && data.AppointmentDate!=''){
			appointmentDate = this.datePipe.transform(data.AppointmentDate, "dd/MM/yyyy");
		 }
		 if(data.dobOrRegDate!= undefined && data.dobOrRegDate!=null && data.dobOrRegDate!=''){
			dobOrRegDate = this.datePipe.transform(data.dobOrRegDate, "dd/MM/yyyy");
		 }
		let ReqObj = {
	  "BrokerBranchCode": "02",
	  "CustomerReferenceNo": this.customerReferenceNo,
	  "InsuranceId": "100002",
	  "BranchCode": "02",
	  "ProductId":"5",
	  "AppointmentDate": appointmentDate,
	  "Address1": data?.Address1,
	  "Address2": data?.Address2,
	  "BusinessType": null,
	  "CityName":data?.CityName,
	  "ClientName": data?.ClientName,
	  "Clientstatus": data?.Clientstatus,
	  "CreatedBy": "kalibroker2",
	  "DobOrRegDate": dobOrRegDate,
	  "Email1": data?.EmailId,
	  "Email2":null,
	  "Email3": null,
	  "Fax": null,
	  "Gender": data?.Gender,
	  "IdNumber": data?.IdNumber,
	  "IdType": data.IdType,
	  "IsTaxExempted": data.isTaxExempted,
	  "Language": "1",
	  "MobileNo1":  data.MobileNo,
	  "MobileNo2":  null,
	  "MobileNo3":  null,
	  "Nationality": data.Country,
	  "Occupation": data?.Occupation,
	  "Placeofbirth": "Chennai",
	  "PolicyHolderType": data.IdType,
	  "PolicyHolderTypeid": data?.PolicyHolderTypeid,
	  "PreferredNotification": data?.PreferredNotification,
	  "RegionCode": "01",
	  "StateCode":  data?.state,
	  "Status": data.Clientstatus,
	  "Street": data?.Street,
	  "TaxExemptedId": null,
	  "TelephoneNo1": data?.TelephoneNo,
	  "TelephoneNo2": null,
	  "TelephoneNo3": null,
	  "Title": data.Title,
	  "VrTinNo": data.vrngst,
	  "SaveOrSubmit": 'Submit'
	  }
	  let urlLink = `${this.CommonApiUrl}api/savecustomerdetails`;
	  this.product.onPostMethodSync(urlLink, ReqObj).subscribe(
		(data: any) => {
		  let res:any = data;
		  console.log(data);
		  if(data.ErrorMessage.length!=0){
			if(res.ErrorMessage){
			  for(let entry of res.ErrorMessage){
			
			//     this.toastr.error(
			//       entry.Field,
			//       entry.Message);
			  }
			}
		  }
		  else{;
			// this.toastr.success(
			// 	  'Customer Details',
			// 	  'Customer Details Inserted/Updated Successfully',);
			  sessionStorage.removeItem('customerReferenceNo');
			  this.router.navigate(['/admin']);
		  }
		},

		(err: any) => { console.log(err); },
	);
	}
}
